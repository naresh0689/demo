from kafka import KafkaProducer
import json
import logging,time

def produce():
    print('inside producer')
    producer = KafkaProducer(bootstrap_servers='localhost:9092',
                             value_serializer=lambda v: json.dumps(v).encode('utf-8'))

    producer.send('social-message', {"message_id":  "abcd1234","user_id":"f1340cab-6409-480a-9bf2-0204e170ed8f", "content": {"message":  "Human computer interaction is very exciting",  "hashtags":  [ "AI", "robots"]},"goals": {"a111": "A survey of user opinion of computer system response time",            "b222" : "The EPS user interface management system", "c333": "Human machine interface for lab abc computer applications"}})
    # producer.send('social-message', {"message_id": "abcd1234"})
    time.sleep(3)
    print('message sent')
if __name__ == '__main__':
    logging.basicConfig(
        format='%(asctime)s.%(msecs)s:%(name)s:%(thread)d:' +
               '%(levelname)s:%(process)d:%(message)s',
        level=logging.INFO
    )
    produce()