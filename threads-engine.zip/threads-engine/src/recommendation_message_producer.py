from kafka import KafkaProducer
import json
import logging,time

class RecommendationProducer:
    def produce(recommendation_message):
        print('inside recommendation producer')
        producer = KafkaProducer(bootstrap_servers='localhost:9092',
                                 value_serializer=lambda v: json.dumps(v).encode('utf-8'))

        future = producer.send('threads_engine_output', recommendation_message)
        # producer.send('socialmessage', {"message_id": "abcd1234"})
        result = future.get(10)
        print(result)
        print('recommendation message sent')
