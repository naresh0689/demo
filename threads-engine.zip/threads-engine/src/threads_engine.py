
from src.correlator import Correlator
from src.sentiment import Sentiment
from src.recommendation_message_producer import RecommendationProducer
import json


class ThreadsEngine:
    def process_message(social_message):
        user_message = social_message["content"]["message"]
        goals_dict = social_message["goals"]
        print(user_message)
        print(goals_dict)
        recommended_ids = Correlator.get_goal_recommendation(user_message, list(goals_dict.keys()),
                                                             list(goals_dict.values()))
        print(recommended_ids)
        score = Sentiment.calculate_sentiment(user_message)
        print(score.polarity)
        print(score.subjectivity)
        result_json = {}
        result_json["message_id"] = social_message["message_id"]
        result_json["user_id"] = social_message["user_id"]
        result_json["content"] = social_message["content"]
        result_json["threads_engine_output"]={}
        result_json["threads_engine_output"]["goals"] = recommended_ids
        result_json["threads_engine_output"]["polarity"] = score.polarity
        result_json["threads_engine_output"]["subjectivity"] = score.subjectivity

        # message_json = json.dumps(result_json)

        print(result_json)
        RecommendationProducer.produce(result_json)
