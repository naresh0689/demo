
from gensim import corpora, models, similarities
from collections import defaultdict
import json

class Correlator:
    def get_goal_recommendation(social_message, goalsid_list, goals_list):

        goals = goals_list

        stoplist = set('for a of the and to in'.lower().split())

        texts = [[word.lower() for word in goal.lower().split() if word not in stoplist ]for goal in goals]

        frequency = defaultdict(int)

        for text in texts:
            for token in text:
                frequency[token] = frequency[token] + 1

        texts = [[token for token in text if frequency[token ] >1]
                 for text in texts]

        dictionary = corpora.Dictionary(texts)
        print(dictionary)

        corpus = [dictionary.doc2bow(text) for text in texts]

        lsi = models.LsiModel(corpus, id2word=dictionary, num_topics=2)
        doc = social_message
        vec_bow = dictionary.doc2bow(doc.lower().split())

        vec_lsi = lsi[vec_bow]

        index = similarities.MatrixSimilarity(lsi[corpus])

        sims = index[vec_lsi]

        sims = sorted(enumerate(sims), key = lambda item: -item[1])
        print(sims)
        recommended_goalids = {}
        for sim in sims:
            recommended_goalids[goalsid_list[sim[0]]] = 1.0*sim[1]
            #numpy float32 is not JSON serializable. multiply 1.0 to convert float32 to 64.

        return recommended_goalids



if __name__ == '__main__':
    path = "C:/Users/MDDharanOF9987/work/2018/Jan/filtered_message.json"
    json_file = open(path)
    json_data = json.load(json_file)
    print(json_data)
    user_message = json_data["content"]["message"]
    goals_dict = json_data["goals"]
    recommended_ids = Correlator.get_goal_recommendation(user_message, list(goals_dict.keys()), list(goals_dict.values()))
    print(recommended_ids)
    for id in recommended_ids:
        print(id +":"+goals_dict[id])