from textblob import TextBlob
from textblob.sentiments import NaiveBayesAnalyzer

class SentimentScore:
    def __init__(self, polarity, subjectivity):
        self.polarity = polarity
        self.subjectivity = subjectivity



class Sentiment:
    def calculate_sentiment(user_message):
        print('inside calculate sentiment')
        textblob_message = TextBlob(user_message)
        score = SentimentScore(textblob_message.sentiment.polarity,textblob_message.sentiment.subjectivity)
        return score