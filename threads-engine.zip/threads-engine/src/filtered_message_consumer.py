from kafka import KafkaConsumer
import json
from src.threads_engine import  ThreadsEngine

# TODO remove hard coding


def consume():
    print('inside consumer')
    consumer = KafkaConsumer(bootstrap_servers='localhost:9092',
                             value_deserializer=lambda m: json.loads(m.decode('utf-8')))
    consumer.subscribe(['transformer'])

    for message in consumer:
        print(message)
        process(message)

def process(message):
    message_json = message.value
    ThreadsEngine.process_message(message_json)

if __name__ == '__main__':
    consume()


