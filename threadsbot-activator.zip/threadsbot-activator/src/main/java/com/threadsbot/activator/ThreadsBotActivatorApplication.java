package com.threadsbot.activator;

import com.threadsbot.activator.listener.KafkaMessageListener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ThreadsBotActivatorApplication {

    public static void main(String[] args) throws Exception {

        ConfigurableApplicationContext context = SpringApplication.run(ThreadsBotActivatorApplication.class, args);
        KafkaMessageListener listener = context.getBean(KafkaMessageListener.class);

        System.in.read();
        context.close();
        System.exit(0);

    }
    @Bean
    public KafkaMessageListener messageListener() {
        return new KafkaMessageListener();
    }
}
