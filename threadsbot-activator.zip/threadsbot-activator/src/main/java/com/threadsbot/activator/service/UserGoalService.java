package com.threadsbot.activator.service;

import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.repository.UserGoalRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserGoalService {

    @Autowired
    private UserGoalRepository userGoalRepository;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    public void save(UserGoal entity) {
        final UserGoal goal = userGoalRepository.save(entity);
        logger.info("Saved user goal entity:"+ goal);
    }

    public UserGoal getUserGoalFromMessageId(String messageId) {
        final UserGoal goal = userGoalRepository.findByMessageId(messageId);
        return goal;
    }

    public List<UserGoal> getUserGoals(String userId) {
        final List<UserGoal> goals = userGoalRepository.findByUserId(userId);
        return goals;
    }
}
