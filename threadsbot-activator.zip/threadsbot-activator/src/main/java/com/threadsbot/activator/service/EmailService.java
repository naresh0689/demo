package com.threadsbot.activator.service;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

import com.threadsbot.activator.entity.EmailMessage;

@Service
public class EmailService {
	
		private String password;
		private String emailId;
		private Session session;
	
		@PostConstruct
		public void init() {
			password = System.getenv().get("LM.EMAIL.PWD");
			emailId = System.getenv().get("LM.EMAIL.USER");
					
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.office365.com");
			props.put("mail.smtp.port", "587");


			session = Session.getInstance(props,
			  new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(emailId, password);
				}
			  });
			
		}
		
		public void sendMessage(final EmailMessage message) {

			try {
				
				Message mimeMessage = new MimeMessage(session);
				mimeMessage.setFrom(new InternetAddress(emailId));
				mimeMessage.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(message.getToAddress()));
				mimeMessage.setSubject(message.getSubject());
				mimeMessage.setText(message.getMessage());

				Transport.send(mimeMessage);
				

			} catch (MessagingException e) {
				throw new RuntimeException(e);
			}
			
		}
		
}
