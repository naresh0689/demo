package com.threadsbot.activator.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.threadsbot.activator.entity.db.ThreadsbotQA;

@Repository
public interface ThreadsbotQARepository extends MongoRepository<ThreadsbotQA, String>{

	
	ThreadsbotQA findById(String id);
    List<ThreadsbotQA> findByUser(String user); 
    ThreadsbotQA findByProcessInstanceId(Long processInstanceId);
    List<ThreadsbotQA> findAll();
}
