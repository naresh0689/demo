package com.threadsbot.activator.entity;

public class Goal {

    public String getId() {
        return id;
    }

    public float getSimilarity() {
        return similarity;
    }

    private String id;

    private String description;
    private float similarity;

    public Goal(String id, float similarity) {
        this.id = id;
        this.similarity = similarity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Goal{" +
                "id='" + id + '\'' +
                ", description='" + description + '\'' +
                ", similarity=" + similarity +
                '}';
    }
}
