package com.threadsbot.activator.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Iterator;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.kie.api.task.model.TaskSummary;
import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.api.model.definition.ProcessDefinition;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.ProcessServicesClient;
import org.kie.server.client.QueryServicesClient;
import org.kie.server.client.UserTaskServicesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.threadsbot.activator.entity.UserProfile;
import com.threadsbot.activator.entity.db.Question;
import com.threadsbot.activator.entity.db.ThreadsbotQA;
import com.threadsbot.activator.entity.db.UserGoalResponse;
import com.threadsbot.activator.repository.ThreadsbotQARepository;
import com.threadsbot.activator.service.JbpmService;

@RestController
@RequestMapping("/jbpm")
public class JbpmController {
	
	@Autowired
	private JbpmService jbpmService;
	private ThreadsbotQA tbQA;
	
	@GetMapping("/processinstances")
	public List<org.kie.server.api.model.instance.TaskSummary> getProcessInstnaces(){
		
		KieServicesClient kieServicesClient = jbpmService.getKieServicesClient();
		// query for all available process definitions
/*		QueryServicesClient queryClient = kieServicesClient.getServicesClient(QueryServicesClient.class);
		List<ProcessDefinition> processes = queryClient.findProcesses(0, 10);
		System.out.println("\t######### Available processes" + processes);
		
		 
		ProcessServicesClient processClient = kieServicesClient.getServicesClient(ProcessServicesClient.class);
		// get details of process definition
		ProcessDefinition definition = processClient.getProcessDefinition(containerId, processId);
		System.out.println("\t######### Definition details: " + definition);
		*/
		
		UserTaskServicesClient taskClient = kieServicesClient.getServicesClient(UserTaskServicesClient.class);
		// find available tasks
		List<org.kie.server.api.model.instance.TaskSummary> tasks = taskClient.findTasksAssignedAsPotentialOwner("naresh", 0, 10);
		System.out.println("\t######### Tasks: " +tasks);
		
		return tasks;	
		
	}
	
	@RequestMapping(value = "/completeTask", method = RequestMethod.POST)
	public boolean completeTask(@RequestBody String usertask) throws ParseException{
		
		KieServicesClient kieServicesClient = jbpmService.getKieServicesClient();
		
		UserTaskServicesClient taskClient = kieServicesClient.getServicesClient(UserTaskServicesClient.class);
		// find available tasks
		List<org.kie.server.api.model.instance.TaskSummary> tasks = taskClient.findTasksAssignedAsPotentialOwner("naresh", 0, 10);
		System.out.println("\t######### Tasks: " +tasks);
		
		  JSONParser parser = new JSONParser();

		  Object obj = parser.parse(usertask);
		  JSONObject jsonObject = (JSONObject) obj;
		  Long processInstanceId = (Long)jsonObject.get("processInstanceId");
		  Long taskId = (Long)jsonObject.get("workItemId");
		  System.out.println("pId : "+processInstanceId+" taskId : "+taskId);
		  JSONObject profile = (JSONObject) jsonObject.get("userProfile");
		  
		  UserProfile userprofile = new UserProfile();
		  userprofile.setId((String) profile.get("id"));
		  userprofile.setGoal((String) profile.get("goal"));
		  userprofile.setFirstQuestion((boolean) profile.get("firstQuestion"));
		  userprofile.setPreviousQuestion((String) profile.get("previousQuestion"));
		  userprofile.setAnswer((String) profile.get("answer"));
		  userprofile.setNextAction(null);
		  userprofile.setNextQuestion((String) profile.get("nextQuestion"));
		  userprofile.setOptions((List<String>) profile.get("options"));
		  
		  System.out.println(userprofile.toString());
		  Question question = new Question();
		  String uniqueID = UUID.randomUUID().toString();
		  question.setId(uniqueID);
		  question.setQuestion(userprofile.getPreviousQuestion());
		  question.setAnswer(userprofile.getAnswer());
		  question.setOptions(userprofile.getOptions());
		  
		  System.out.println(question.toString());
		  
		  ThreadsbotQA tbQA = new ThreadsbotQA();
		  if(jbpmService.getThreadsbotQAFromProcessId(processInstanceId)!= null){
			  tbQA = jbpmService.getThreadsbotQAFromProcessId(processInstanceId);
		  } else {
			  tbQA.setProcessInstanceId(processInstanceId);
		  }
			  if(tbQA.getQuestions()==null || tbQA.getQuestions().size()==0){
			  List<Question> questions = new ArrayList<Question>();
			  questions.add(question);
			  tbQA.setQuestions(questions);
			  } else {
		  //} else {
			  tbQA.getQuestions().add(question);
			  }
		  //}
		  
		  jbpmService.save(tbQA);
		  
/*		taskClient.releaseTask("lm", taskId, "naresh");
		System.out.println("released");
		taskClient.claimTask("lm", taskId, "naresh");
		System.out.println("claimed");
		taskClient.startTask("lm", taskId, "naresh");
		System.out.println("started");*/
		Map<String, Object> params = new HashMap<String, Object>();
params.put("userprofileOut", profile);		

		
		taskClient.completeTask("lm", taskId, "naresh", params);
		System.out.println("completed");
		return true;
		
		
	}
	
	@RequestMapping(value = "/getQuestionsAndAnswers/{processInstanceId}", method = RequestMethod.GET)
    public @ResponseBody 
    ThreadsbotQA getThreadsbotQAFromProcessId(@PathVariable("processInstanceId") Long processInstanceId) {
		System.out.println("in get threadsbot Questions");
    	return jbpmService.getThreadsbotQAFromProcessId(processInstanceId);
    }
	
}
