package com.threadsbot.activator.constants;

public enum UserGoalResponseStatus {
	RECOMMENDED,ACCEPTED,DECLINED

}
