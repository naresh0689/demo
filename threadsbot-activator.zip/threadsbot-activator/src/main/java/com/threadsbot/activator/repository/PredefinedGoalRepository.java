package com.threadsbot.activator.repository;

import com.threadsbot.activator.entity.Goal;
import com.threadsbot.activator.entity.db.PredefinedGoal;
import com.threadsbot.activator.entity.db.UserGoal;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PredefinedGoalRepository extends MongoRepository<PredefinedGoal, String> {
    PredefinedGoal findById(String id);
}