package com.threadsbot.activator.controller;

import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.service.UserGoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/usergoal")
public class UserGoalController {

    @Autowired
    private UserGoalService userGoalService;

    @RequestMapping(value = "/{messageId}")
    public @ResponseBody
    UserGoal getGoalFromMessageId(@PathVariable("messageId") String messageId) {

        return userGoalService.getUserGoalFromMessageId(messageId);
    }

    @RequestMapping(value = "/user/{userId}")
    public @ResponseBody
    List<UserGoal> getUserGoals(@PathVariable("userId") String userId) {

        return userGoalService.getUserGoals(userId);
    }
}
