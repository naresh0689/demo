package com.threadsbot.activator.controller;

import com.threadsbot.activator.constants.UserGoalResponseStatus;
import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.entity.db.UserGoalResponse;
import com.threadsbot.activator.service.UserGoalResponseService;
import com.threadsbot.activator.service.UserGoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


@Controller
@RequestMapping("/usergoalresponse")
public class UserGoalResponseController {


        @Autowired
        private UserGoalResponseService userGoalResponseService;

        @RequestMapping(value = "/user/{userId}", method = RequestMethod.GET
                )
        public @ResponseBody 
        List<UserGoalResponse> getUserGoalResponseFromUserId(@PathVariable("userId") String userId) {
        	return userGoalResponseService.getUserGoalsResponseFromUserId(userId);
        }
        
        @RequestMapping(value = "/user/{userId}/status/{responseStatus}", method = RequestMethod.GET)
        public @ResponseBody
        List<UserGoalResponse> getUserGoalResponseFromUserIdAndStatus(@PathVariable("userId") String userId,
                                                             @PathVariable("responseStatus") String responseStatus) {

            return userGoalResponseService.getUserGoalsResponseFromUserIdAndStatus(userId, responseStatus);
        }

        @RequestMapping(value = "/user/{userId}/goal/{goalId}", method = RequestMethod.POST)
        public @ResponseBody
        UserGoalResponse addUserGoalResponse(@PathVariable("userId") String userId,
                                    @PathVariable("goalId") String goalId) {
            UserGoalResponse response = new UserGoalResponse();
            response.setUserId(userId);
            response.setGoalId(goalId);
            response.setResponseStatus(UserGoalResponseStatus.RECOMMENDED.toString());
            return userGoalResponseService.save(response);
        }
        
        @RequestMapping(value = "/user/{userId}/goal/{goalId}/{responseStatus}", method = RequestMethod.POST)
        public @ResponseBody
        UserGoalResponse updateUserGoalResponse(@PathVariable("userId") String userId,
                                    @PathVariable("goalId") String goalId, @PathVariable("responseStatus") String responseStatus) {
            UserGoalResponse response = userGoalResponseService.findByUserIdAndGoalId(userId, goalId);
            response.setResponseStatus(responseStatus);
            return userGoalResponseService.save(response);
        }
        
        @RequestMapping(value = "/updatestatus", method = RequestMethod.POST)
        public @ResponseBody
        UserGoalResponse updateUserGoalResponse(@RequestBody UserGoalResponse input) {
        	UserGoalResponse response = userGoalResponseService.findByUserIdAndGoalId(input.getUserId(), input.getGoalId());
        	response.setResponseStatus(input.getResponseStatus());
        	return userGoalResponseService.save(response);
        }
        
    }

