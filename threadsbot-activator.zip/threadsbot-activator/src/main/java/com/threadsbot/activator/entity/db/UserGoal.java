package com.threadsbot.activator.entity.db;


import com.threadsbot.activator.entity.Goal;


import java.util.List;

public class UserGoal {

    private String id;

    private String messageId;

    private String message;

    public UserGoal(String messageId, List<Goal> goals, float polarity, float subjectivity) {
        this.messageId = messageId;
        this.goals = goals;
        this.polarity = polarity;
        this.subjectivity = subjectivity;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private String userId;

    private List<Goal> goals;

    private float polarity;

    private float subjectivity;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

	public List<Goal> getGoals() {
		return goals;
	}

	public float getPolarity() {
		return polarity;
	}

	public float getSubjectivity() {
		return subjectivity;
	}


}
