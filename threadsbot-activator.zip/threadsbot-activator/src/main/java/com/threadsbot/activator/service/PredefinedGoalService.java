package com.threadsbot.activator.service;

import com.threadsbot.activator.entity.db.PredefinedGoal;
import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.repository.PredefinedGoalRepository;
import com.threadsbot.activator.repository.UserGoalRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PredefinedGoalService {

    @Autowired
    private PredefinedGoalRepository predefinedGoalRepository;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    public PredefinedGoal getPredefinedGoal(String id) {
        final PredefinedGoal goal = predefinedGoalRepository.findById(id);
        return goal;
    }

}
