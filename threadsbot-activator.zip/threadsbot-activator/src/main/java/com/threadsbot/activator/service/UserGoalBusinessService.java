package com.threadsbot.activator.service;

import com.threadsbot.activator.entity.ThreadsEngineResult;
import com.threadsbot.activator.entity.db.UserGoal;

public class UserGoalBusinessService {

    public UserGoal generateUserGoal(String messageId, String userId, String userMessage, ThreadsEngineResult recommendation) {
        UserGoal goal = new UserGoal(messageId, recommendation.getGoalsList(), recommendation.getPolarity(),
                recommendation.getSubjectivity());
        goal.setMessage(userMessage);
        goal.setUserId(userId);
        return goal;
    }
}
