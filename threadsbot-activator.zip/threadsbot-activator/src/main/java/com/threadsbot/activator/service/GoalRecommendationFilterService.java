package com.threadsbot.activator.service;

import com.threadsbot.activator.entity.Goal;
import com.threadsbot.activator.entity.ThreadsEngineResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class GoalRecommendationFilterService {

    @Value(value = "${goals.similarity.cutoff}")
    private float goalsSimilarityCutoff;

    @Value(value = "${message.polarity.cutoff}")
    private float messagePolarityCutoff;

    @Value(value = "${message.subjectivity.cutoff}")
    private float messageSubjectivityCutoff;

    public ThreadsEngineResult filter(final ThreadsEngineResult recommendation, final Map<String, String> existingGoals) {
        boolean isValid = false;
        if(recommendation.getPolarity() > messagePolarityCutoff &&
                recommendation.getSubjectivity() > messageSubjectivityCutoff) {
            List<Goal> filteredGoals = new ArrayList<>(recommendation.getGoalsList().size());
            for(Goal goal : recommendation.getGoalsList()) {
            	if(existingGoals.containsKey(goal.getId())) {
            		continue;
            	}
                if(goal.getSimilarity() > goalsSimilarityCutoff) {
                    filteredGoals.add(goal);
                }
            }
            if(filteredGoals.size() > 0) {
                isValid = true;
                recommendation.setGoalsList(filteredGoals);
            }

        }
        recommendation.setValid(isValid);
        return recommendation;
    }
}
