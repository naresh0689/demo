package com.threadsbot.activator.entity.db;
//TODO move to a commons project
public class PredefinedGoal {

    private String id;
    private String goalName;

    public PredefinedGoal(String id, String goalName) {
        this.id = id;
        this.goalName = goalName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGoalName() {
        return goalName;
    }

    public void setGoalName(String goalName) {
        this.goalName = goalName;
    }
}
