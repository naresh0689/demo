package com.threadsbot.activator.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.threadsbot.activator.entity.db.UserGoalResponse;

@Repository
public interface UserGoalResponseRepository extends MongoRepository<UserGoalResponse, String> {
    UserGoalResponse findById(String id);
    List<UserGoalResponse> findUserGoalResponseByUserIdAndResponseStatus(String userId, String responseStatus);
    List<UserGoalResponse> findUserGoalResponseByUserId(String userId);
    UserGoalResponse findByUserIdAndGoalId(String userId, String goalId);
}
