package com.threadsbot.activator.constants;

public class RecommendationMessageConstants {

    public static final String MESSAGE_ID = "message_id";
    public static final String RECOMMENDATION = "threads_engine_output";
    public static final String GOALS = "goals";
    public static final String POLARITY = "polarity";
    public static final String SUBJECTIVITY = "subjectivity";
    public static final String CONTENT = "content";
    public static final String MESSAGE = "message";
    public static final String USER_ID = "user_id";
}
