package com.threadsbot.activator.listener;

import com.threadsbot.activator.service.ThreadsBotActivationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;

public class KafkaMessageListener {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ThreadsBotActivationService recommendationProcessorService;

    @KafkaListener(topics = "${kafka.topic.name}", group = "goals", containerFactory = "goalsKafkaListenerContainerFactory")
    public void listenGroupGoals(String message) {
        if(logger.isDebugEnabled()) {
            logger.debug("Received Message in group 'goals': " + message);
        }
        recommendationProcessorService.process(message);
    }
}
