package com.threadsbot.activator.service;

import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.threadsbot.activator.entity.db.ThreadsbotQA;
import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.repository.ThreadsbotQARepository;
import com.threadsbot.activator.repository.UserGoalRepository;

@Service
public class JbpmService {
	
    @Autowired
    private ThreadsbotQARepository threadsbotQARepository ;
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	
	public KieServicesClient getKieServicesClient(){
		
		String serverUrl = "http://localhost:8080/kie-server/services/rest/server";
		String user = "naresh";
		String password = "naresh1!";
		 
		String containerId = "lm";
		String processId = "jbpmdemo";
		 
		KieServicesConfiguration configuration = KieServicesFactory.newRestConfiguration(serverUrl, user, password);
		// other formats supported MarshallingFormat.JSON or MarshallingFormat.XSTREAM
		configuration.setMarshallingFormat(MarshallingFormat.JSON);
		// in case of custom classes shall be used they need to be added and client needs to be created with class loader that has these classes available 
		//configuration.addJaxbClasses(extraClasses);
		//KieServicesClient kieServicesClient =  KieServicesFactory.newKieServicesClient(configuration, kieContainer.getClassLoader());
		KieServicesClient kieServicesClient =  KieServicesFactory.newKieServicesClient(configuration);
		
		return kieServicesClient;
		
	}
	
    public void save(ThreadsbotQA entity) {
        final ThreadsbotQA tbQA = threadsbotQARepository.save(entity);
        logger.info("Saved ThreadsbotQA :"+ tbQA);
    }

    public ThreadsbotQA getThreadsbotQAFromProcessId(Long processInstanceId) {
        final ThreadsbotQA threadsbotQA  = threadsbotQARepository.findByProcessInstanceId(processInstanceId);
        return threadsbotQA;
    }
}
