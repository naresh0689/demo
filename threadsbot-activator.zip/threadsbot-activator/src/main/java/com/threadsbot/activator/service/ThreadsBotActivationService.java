package com.threadsbot.activator.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.threadsbot.activator.constants.RecommendationMessageConstants;
import com.threadsbot.activator.constants.UserGoalResponseStatus;
import com.threadsbot.activator.entity.EmailMessage;
import com.threadsbot.activator.entity.Goal;
import com.threadsbot.activator.entity.ThreadsEngineResult;
import com.threadsbot.activator.entity.db.PredefinedGoal;
import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.entity.db.UserGoalResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class ThreadsBotActivationService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private GoalRecommendationFilterService filterService;

	@Autowired
	private UserGoalService userGoalService;

	@Autowired
	private UserGoalResponseService userGoalResponseService;

	@Autowired
	private PredefinedGoalService predefinedGoalService;
	
	@Autowired
	private EmailService emailService;

	public void process(String message) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode messageJsonNode = mapper.readTree(message);
			String messageId = messageJsonNode.get(RecommendationMessageConstants.MESSAGE_ID).asText();
			String userId = messageJsonNode.get(RecommendationMessageConstants.USER_ID).asText();
			JsonNode recommendationNode = messageJsonNode.get(RecommendationMessageConstants.RECOMMENDATION);
			JsonNode goalsNode = recommendationNode.get(RecommendationMessageConstants.GOALS);
			Iterator<String> goalsNodeIt = goalsNode.fieldNames();

			List<Goal> goals = new ArrayList<>();
			while (goalsNodeIt.hasNext()) {
				String goalId = goalsNodeIt.next();
				float similarityScore = goalsNode.get(goalId).floatValue();
				Goal goal = new Goal(goalId, similarityScore);
				// TODO move predefined goals to cache
				PredefinedGoal predefinedGoal = predefinedGoalService.getPredefinedGoal(goalId);
				goal.setDescription(predefinedGoal.getGoalName());
				goals.add(goal);

			}

			float polarity = recommendationNode.get(RecommendationMessageConstants.POLARITY).floatValue();
			float subjectivity = recommendationNode.get(RecommendationMessageConstants.SUBJECTIVITY).floatValue();

			ThreadsEngineResult recommendation = new ThreadsEngineResult(goals, subjectivity, polarity);
			ThreadsEngineResult filteredRecommendation = filterService.filter(recommendation);
			if (filteredRecommendation.isValid()) {
				JsonNode contentNode = messageJsonNode.get(RecommendationMessageConstants.CONTENT);
				String userMessage = contentNode.get(RecommendationMessageConstants.MESSAGE).asText();
				UserGoalBusinessService userGoalBusinessService = new UserGoalBusinessService();
				UserGoal goal = userGoalBusinessService.generateUserGoal(messageId, userId, userMessage,
						filteredRecommendation);
				userGoalService.save(goal);
				for (Goal filteredGoal : goal.getGoals()) {
					UserGoalResponse response = new UserGoalResponse();
					response.setUserId(userId);
					response.setGoalId(filteredGoal.getId());
					response.setGoalDescription(filteredGoal.getDescription());
					response.setResponseStatus(UserGoalResponseStatus.RECOMMENDED.toString());
					userGoalResponseService.save(response);
				}
				EmailMessage emailMessage = new EmailMessage();
				emailMessage.setMessage("You have a new goal recommendation from LM-Threads");
				emailMessage.setSubject("LM-Threads");
				//TODO get to address from user collection
				emailMessage.setToAddress("nggurijala@leggmason.com");
				emailService.sendMessage(emailMessage);
				
			} else {
				logger.info("Message id:" + messageId + "..filter result invalid:" + recommendation.toString());
			}

		} catch (Exception e) {
			logger.error("IOexception while processing recommendation message:" + message, e);
		}

	}

	public static void main(String a[]) {
		String message = "{\"message_id\": \"abcd1234\", \"content\": {\"message\": \"Human computer interaction is very exciting\",\"source\":\"twitter\" ,\"hashtags\": [\"AI\", \"robots\"]}, \"recommendation\": {\"goals\": {\"c333\": 1.0, \"a111\": 0.4472135901451111, \"b222\": 0.4472135901451111}, \"polarity\": 0.195, \"subjectivity\": 0.55}}";
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode messageJsonNode = mapper.readTree(message);

			System.out.println(messageJsonNode);
			System.out.println(messageJsonNode.get("message_id").asText());
			JsonNode recommendationNode = messageJsonNode.get("recommendation");
			JsonNode goalsNode = recommendationNode.get("goals");
			Iterator<String> goalsNodeIt = goalsNode.fieldNames();
			while (goalsNodeIt.hasNext()) {
				System.out.println(goalsNode.get(goalsNodeIt.next()));
			}

			float polarity = recommendationNode.get(RecommendationMessageConstants.POLARITY).floatValue();
			float subjectivity = recommendationNode.get(RecommendationMessageConstants.SUBJECTIVITY).floatValue();

		} catch (Exception e) {

		}
	}

}
