package com.threadsbot.activator.entity.db;

import java.util.List;

import org.springframework.data.annotation.Id;

public class ThreadsbotQA {
	
	@Id
	private String id;
	private Long processInstanceId;
	private String user;
	private List<Question> questions;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getProcessInstanceId() {
		return processInstanceId;
	}
	public void setProcessInstanceId(Long processInstanceId) {
		this.processInstanceId = processInstanceId;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	

}
