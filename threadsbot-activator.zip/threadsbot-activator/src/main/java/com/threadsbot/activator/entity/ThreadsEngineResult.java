package com.threadsbot.activator.entity;


import java.util.List;

public class ThreadsEngineResult {

    public void setGoalsList(List<Goal> goalsList) {
        this.goalsList = goalsList;
    }

    private List<Goal> goalsList;
    private float subjectivity;
    private float polarity;

    private boolean isValid;

    public ThreadsEngineResult(List<Goal> goalsList, float subjectivity, float polarity) {
        this.goalsList = goalsList;
        this.subjectivity = subjectivity;
        this.polarity = polarity;
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean valid) {
        isValid = valid;
    }

    public List<Goal> getGoalsList() {
        return goalsList;
    }

    public float getSubjectivity() {
        return subjectivity;
    }

    public float getPolarity() {
        return polarity;
    }

    @Override
    public String toString() {
        return "ThreadsEngineResult{" +
                "goalsList=" + goalsList +
                ", subjectivity=" + subjectivity +
                ", polarity=" + polarity +
                '}';
    }
}
