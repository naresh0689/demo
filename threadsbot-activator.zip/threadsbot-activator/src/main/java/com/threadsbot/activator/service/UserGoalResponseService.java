package com.threadsbot.activator.service;

import com.threadsbot.activator.entity.db.UserGoal;
import com.threadsbot.activator.entity.db.UserGoalResponse;
import com.threadsbot.activator.repository.UserGoalResponseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserGoalResponseService {

    @Autowired
    private UserGoalResponseRepository userGoalResponseRepository;

    public UserGoalResponse save(UserGoalResponse entity) {
        final UserGoalResponse userGoalResponse = userGoalResponseRepository.save(entity);
        return userGoalResponse;
    }

    public List<UserGoalResponse> getUserGoalsResponseFromUserIdAndStatus(String userId, String responseStatus) {
        final List<UserGoalResponse> userGoalResponses = userGoalResponseRepository.findUserGoalResponseByUserIdAndResponseStatus(userId, responseStatus);
        return  userGoalResponses;
    }
    
    public List<UserGoalResponse> getUserGoalsResponseFromUserId(String userId) {
        final List<UserGoalResponse> userGoalResponses = userGoalResponseRepository.findUserGoalResponseByUserId(userId);
        return  userGoalResponses;
    }
    
    public UserGoalResponse findByUserIdAndGoalId(String userId, String goalId) {
    	final UserGoalResponse userGoalResponse = userGoalResponseRepository.findByUserIdAndGoalId(userId, goalId);
    	return userGoalResponse;
    	
    }
}
