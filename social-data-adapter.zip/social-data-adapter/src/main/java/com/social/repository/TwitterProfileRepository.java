package com.social.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.social.domain.TwitterProfile;

public interface TwitterProfileRepository extends MongoRepository<TwitterProfile, String> {
  public TwitterProfile findByHandle(String handle);
}