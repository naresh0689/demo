package com.social.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.Query;
import com.social.domain.*;
import java.util.*;
/**
 * Repository for {@link SocialProfile} domain object.
 *
 * @author Shris Infotech
 */
@Repository
public interface SocialProfileRepository extends MongoRepository<SocialProfile, String> {
    @Query("{'_id':{$eq: ?0}}")
    SocialProfile findById(String id);
	SocialProfile findByUserId(String userId);
	List<SocialProfile> findByIsActive(Boolean isActive);
	
}
