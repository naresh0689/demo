package com.social.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.Query;
import com.social.domain.*;
import java.util.*;
/**
 * Repository for {@link SocialData} domain object.
 *
 * @author Shris Infotech
 */
@Repository
public interface SocialDataRepository extends MongoRepository<SocialData, String> {
	SocialData findById(String id);
	SocialData findByUser(String user);
	SocialData findByRawMessage(String rawMessage);
	List<SocialData> findBySource(SocialSource source);
	List<SocialData> findByStatus(PublishingStatus status);
}
