package com.social.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.MessageSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.social.domain.SocialDataPollLog;
import com.social.businessobject.SocialDataPollLogBusinessLogic;
import com.social.businessobject.Context;

/**
 * Service object for {@link SocialDataPollLog}
 * 
 * 
 * @see SocialDataPollLogRepository
 * @see SocialDataPollLogBusinessLogic#perform(MarketData, Context)
 * @see SocialDataPollLogBusinessLogic#perform(java.util.Collection, Context)
 * 
 * @author Shris Infotech
 */
@Service
//@CacheConfig(cacheNames = "SocialDataPollLogs")
public class SocialDataPollLogBusinessService extends GenericBusinessService{
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	SocialDataPollLogDataService socialDataPollLogDataService;
	
	final SocialDataPollLogBusinessLogic socialDataPollLogBusinessLogic = new SocialDataPollLogBusinessLogic();
	
	
	
	/**
	 * This method is paginated version of {@link SocialDataPollLogService#fetchAllRecords()}
	 * 
	 * @param page
	 * @return
	 * 
	 *  TO DO: Add @Cacheable to the method if the objects needs to be
	 *  cached. This needs to work in conjunction with enabling cache. Check {@link Application} for cache configuration.
	 *  Ex: @Cacheable(unless = "#result != null and #result.size() == 0")
	 */	
	public Page<SocialDataPollLog> readAll(final PageRequest page) {
		final Page<SocialDataPollLog> entities = socialDataPollLogDataService.readAll(page);
		socialDataPollLogBusinessLogic.perform(entities.getContent(), Context.GET);
		return entities;
	}
	
	/**
	 * Fetches all the entities of type {@link SocialDataPollLog} from the data base.
	 * 
	 * @return
	 * 
	 *  TO DO: Add @Cacheable to the method if the objects needs to be
	 *  cached. This needs to work in conjunction with enabling cache. Check {@link Application} for cache configuration.
	 *  Ex: @Cacheable(unless = "#result != null and #result.size() == 0")
	 */
	public List<SocialDataPollLog> fetchAllRecords() {
		final List<SocialDataPollLog> entities = socialDataPollLogDataService.fetchAllRecords();
		socialDataPollLogBusinessLogic.perform(entities, Context.GET);
		return entities;
	}
	
	/**
	 *
     * Finds list of {@link SocialDataPollLog} objects matching given query.
     * 
	 * @param query
	 * @return
	 */
	public List<SocialDataPollLog> filter(Query query) {
		final List<SocialDataPollLog> entities = socialDataPollLogDataService.filter(query);
		socialDataPollLogBusinessLogic.perform(entities, Context.FIND);
		return entities;
	}
	
	/**
	 * Returns count of {@link SocialDataPollLog} objects matching a given query.
	 * 
	 * @param query
	 * @return count
	 */
	public Long getCount(Query query) {
		return socialDataPollLogDataService.getCount(query);
	}
	
	/**
	 *
     *  Returns details of {@link SocialDataPollLog} object for a given id.
     * 
	 * @param emp
	 * @return
	 */
	public SocialDataPollLog read(SocialDataPollLog entity) {
		socialDataPollLogBusinessLogic.perform(entity, Context.GET);
		return socialDataPollLogDataService.read(entity);
	}
	
	/**
	 * Executes business logic on {@link SocialDataPollLog} and persists it to the DB.
	 * 
	 * @param entity
	 *            Entity to persist in the DB
	 * @return newly created {@link SocialDataPollLog}
	 * 
	 *  TO DO: Add @CachePut to the method if the object needs to be
	 *  cached. This needs to work in conjunction with enabling cache. Check {@link Application} for cache configuration.
	 */
	public SocialDataPollLog create(SocialDataPollLog entity) {
		socialDataPollLogBusinessLogic.perform(entity, Context.CREATE);
		return socialDataPollLogDataService.save(entity);
	}
	
	/**
	 * 
	 * Updates an existing {@link SocialDataPollLog} in the database.
	 * 
	 * 
	 * @param entity
	 * @return
	 * 
	 * TO DO: If the {@link SocialDataPollLog} is cached, update the cache as well.
	 */
	public SocialDataPollLog update(SocialDataPollLog entity) {
		SocialDataPollLog existingEntity = socialDataPollLogDataService.findById(entity.getId());

		if (existingEntity == null) {
			logger.error("Cannot update SocialDataPollLog. No entity with id " + entity.getId() + " exists");
			throw new IllegalArgumentException("Cannot update SocialDataPollLog. No entity with id " + entity.getId() + " exists");
		}
		socialDataPollLogBusinessLogic.perform(entity, Context.UPDATE);
		return socialDataPollLogDataService.save(entity);
	}
	
	/**
	 * 
	 * Deletes an existing {@link SocialDataPollLog} from the database.
	 * 
	 * 
	 * @param entity
	 * @return
	 * 
	 * TO DO: If the {@link SocialDataPollLog} is cached, delete from cache as well.
	 * Ex: @CacheEvict
	 */
	public Boolean delete(SocialDataPollLog entity) {
		SocialDataPollLog existingEntity = socialDataPollLogDataService.findById(entity.getId());

		if (existingEntity == null) {
			logger.error("Cannot delete SocialDataPollLog. No entity with id " + entity.getId() + " exists");
			throw new IllegalArgumentException("Cannot delete SocialDataPollLog. No entity with id " + entity.getId() + " exists");
		}
		super.preDelete(entity);
		socialDataPollLogBusinessLogic.perform(entity, Context.DELETE);
		socialDataPollLogDataService.delete(existingEntity);
		super.postDelete(entity);
		return true;
	}
}
