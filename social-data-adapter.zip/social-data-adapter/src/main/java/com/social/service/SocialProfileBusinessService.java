package com.social.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.MessageSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.social.domain.SocialProfile;
import com.social.businessobject.SocialProfileBusinessLogic;
import com.social.businessobject.Context;

/**
 * Service object for {@link SocialProfile}
 * 
 * 
 * @see SocialProfileRepository
 * @see SocialProfileBusinessLogic#perform(MarketData, Context)
 * @see SocialProfileBusinessLogic#perform(java.util.Collection, Context)
 * 
 * @author Shris Infotech
 */
@Service
//@CacheConfig(cacheNames = "SocialProfiles")
public class SocialProfileBusinessService extends GenericBusinessService{
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	SocialProfileDataService socialProfileDataService;
	
	final SocialProfileBusinessLogic socialProfileBusinessLogic = new SocialProfileBusinessLogic();
	
	
	/**
	 * This method is paginated version of {@link SocialProfileService#fetchAllRecords()}
	 * 
	 * @param page
	 * @return
	 * 
	 *  TO DO: Add @Cacheable to the method if the objects needs to be
	 *  cached. This needs to work in conjunction with enabling cache. Check {@link Application} for cache configuration.
	 *  Ex: @Cacheable(unless = "#result != null and #result.size() == 0")
	 */	
	public Page<SocialProfile> readAll(final PageRequest page) {
		final Page<SocialProfile> entities = socialProfileDataService.readAll(page);
		socialProfileBusinessLogic.perform(entities.getContent(), Context.GET);
		return entities;
	}
	
	/**
	 * Fetches all the entities of type {@link SocialProfile} from the data base.
	 * 
	 * @return
	 * 
	 *  TO DO: Add @Cacheable to the method if the objects needs to be
	 *  cached. This needs to work in conjunction with enabling cache. Check {@link Application} for cache configuration.
	 *  Ex: @Cacheable(unless = "#result != null and #result.size() == 0")
	 */
	public List<SocialProfile> fetchAllRecords() {
		final List<SocialProfile> entities = socialProfileDataService.fetchAllRecords();
		socialProfileBusinessLogic.perform(entities, Context.GET);
		return entities;
	}
	
	/**
	 *
     * Finds list of {@link SocialProfile} objects matching given query.
     * 
	 * @param query
	 * @return
	 */
	public List<SocialProfile> filter(Query query) {
		final List<SocialProfile> entities = socialProfileDataService.filter(query);
		socialProfileBusinessLogic.perform(entities, Context.FIND);
		return entities;
	}
	
	/**
	 * Returns count of {@link SocialProfile} objects matching a given query.
	 * 
	 * @param query
	 * @return count
	 */
	public Long getCount(Query query) {
		return socialProfileDataService.getCount(query);
	}
	
	/**
	 *
     *  Returns details of {@link SocialProfile} object for a given id.
     * 
	 * @param emp
	 * @return
	 */
	public SocialProfile read(SocialProfile entity) {
		socialProfileBusinessLogic.perform(entity, Context.GET);
		return socialProfileDataService.read(entity);
	}
	
	/**
	 * Executes business logic on {@link SocialProfile} and persists it to the DB.
	 * 
	 * @param entity
	 *            Entity to persist in the DB
	 * @return newly created {@link SocialProfile}
	 * 
	 *  TO DO: Add @CachePut to the method if the object needs to be
	 *  cached. This needs to work in conjunction with enabling cache. Check {@link Application} for cache configuration.
	 */
	public SocialProfile create(SocialProfile entity) {
		socialProfileBusinessLogic.perform(entity, Context.CREATE);
		return socialProfileDataService.save(entity);
	}
	
	/**
	 * 
	 * Updates an existing {@link SocialProfile} in the database.
	 * 
	 * 
	 * @param entity
	 * @return
	 * 
	 * TO DO: If the {@link SocialProfile} is cached, update the cache as well.
	 */
	public SocialProfile update(SocialProfile entity) {
		SocialProfile existingEntity = socialProfileDataService.findById(entity.getId());

		if (existingEntity == null) {
			logger.error("Cannot update SocialProfile. No entity with id " + entity.getId() + " exists");
			throw new IllegalArgumentException("Cannot update SocialProfile. No entity with id " + entity.getId() + " exists");
		}
		socialProfileBusinessLogic.perform(entity, Context.UPDATE);
		return socialProfileDataService.save(entity);
	}
	
	/**
	 * 
	 * Deletes an existing {@link SocialProfile} from the database.
	 * 
	 * 
	 * @param entity
	 * @return
	 * 
	 * TO DO: If the {@link SocialProfile} is cached, delete from cache as well.
	 * Ex: @CacheEvict
	 */
	public Boolean delete(SocialProfile entity) {
		SocialProfile existingEntity = socialProfileDataService.findById(entity.getId());

		if (existingEntity == null) {
			logger.error("Cannot delete SocialProfile. No entity with id " + entity.getId() + " exists");
			throw new IllegalArgumentException("Cannot delete SocialProfile. No entity with id " + entity.getId() + " exists");
		}
		super.preDelete(entity);
		socialProfileBusinessLogic.perform(entity, Context.DELETE);
		socialProfileDataService.delete(existingEntity);
		super.postDelete(entity);
		return true;
	}
	
	/**
	 * Finds active SocialProfile's
	 */
	public List<SocialProfile> findActiveSocialProfiles() {
		return socialProfileDataService.findActiveSocialProfiles();
	}
}
