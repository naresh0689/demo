package com.social.service;

/**
 * Super class for the data services.
 * 
 * @author Shris Infotech
 *
 */
public class GenericDataService {
	
}
