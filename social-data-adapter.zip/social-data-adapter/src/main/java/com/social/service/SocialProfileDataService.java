package com.social.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.context.MessageSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.social.domain.SocialProfile;
import com.social.repository.SocialProfileRepository;
import com.social.businessobject.SocialProfileBusinessLogic;
import com.social.businessobject.SocialProfileDataEnricher;
import com.social.businessobject.Context;

/**
 * Service object for {@link SocialProfile}
 * 
 * 
 * @see SocialProfileRepository
 * @see SocialProfileBusinessLogic#perform(SocialProfile, Context)
 * @see SocialProfileBusinessLogic#perform(java.util.Collection, Context)
 * 
 * @author Shris Infotech
 */
@Service
public class SocialProfileDataService extends GenericDataService{

	@Autowired
	private SocialProfileRepository entityRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	private SocialProfileDataEnricher socialProfileDataEnricher = new SocialProfileDataEnricher();
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	/**
	 * Saves SocialProfile to persistence store.
	 */
	public SocialProfile save(SocialProfile entity) {
		final SocialProfile socialProfile = entityRepository.save(entity);
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(socialProfile);
		return socialProfile;
	}
	
	/**
	 * Finds SocialProfile with a given id from persistence store.
	 */
	public SocialProfile findById(final String id) {
		final SocialProfile socialProfile = entityRepository.findById(id);
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(socialProfile);
		return socialProfile;
	}
	
	/**
	 * Reads all the SocialProfile entities from the persistence store with the size limit matching the page request.
	 */
	public Page<SocialProfile> readAll(final PageRequest page) {
		final Page<SocialProfile> entities = entityRepository.findAll(page);
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads all the SocialProfile entities from the persistence store.
	 */
	public List<SocialProfile> fetchAllRecords() {
		final List<SocialProfile> entities = entityRepository.findAll();
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads SocialProfile entities from the persistence store matching a give query.
	 */
	public List<SocialProfile> filter(Query query) {
		final List<SocialProfile> entities = mongoTemplate.find(query, SocialProfile.class);
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Returns count of SocialProfile entities from the persistence store.
	 */
	public Long getCount(Query query) {
		return mongoTemplate.count(query,SocialProfile.class);
	}
	
	/**
	 * Reads SocialProfile from persistence store for a given id.
	 * 
	 * @param entity
	 * @return
	 */
	public SocialProfile read(SocialProfile entity) {
		final SocialProfile socialProfile =  entityRepository.findById(entity.getId());
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(socialProfile);
		return socialProfile;
	}
	
	/**
	 * Updates SocialProfile in persistence store.
	 */
	public SocialProfile update(SocialProfile entity) {
		final SocialProfile socialProfile = entityRepository.save(entity);
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(socialProfile);
		return socialProfile;
	}
	
	/**
	 * Deletes SocialProfile in persistence store.
	 */
	public Boolean delete(SocialProfile entity) {
		entityRepository.delete(entity);
		return true;
	}
	
	/**
	 * Finds active SocialProfile's
	 */
	public List<SocialProfile> findActiveSocialProfiles() {
		List<SocialProfile> socialProfiles = entityRepository.findByIsActive(true);
		//If needed, enrich data before returning to the business service.
		socialProfileDataEnricher.enrich(socialProfiles);
		return socialProfiles;
	}
}
