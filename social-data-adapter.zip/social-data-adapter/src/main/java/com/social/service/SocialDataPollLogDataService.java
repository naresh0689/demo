package com.social.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.context.MessageSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.social.domain.SocialDataPollLog;
import com.social.repository.SocialDataPollLogRepository;
import com.social.businessobject.SocialDataPollLogBusinessLogic;
import com.social.businessobject.SocialDataPollLogDataEnricher;
import com.social.businessobject.Context;

/**
 * Service object for {@link SocialDataPollLog}
 * 
 * 
 * @see SocialDataPollLogRepository
 * @see SocialDataPollLogBusinessLogic#perform(SocialDataPollLog, Context)
 * @see SocialDataPollLogBusinessLogic#perform(java.util.Collection, Context)
 * 
 * @author Shris Infotech
 */
@Service
public class SocialDataPollLogDataService extends GenericDataService{

	@Autowired
	private SocialDataPollLogRepository entityRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	private SocialDataPollLogDataEnricher socialDataPollLogDataEnricher = new SocialDataPollLogDataEnricher();
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	/**
	 * Saves SocialDataPollLog to persistence store.
	 */
	public SocialDataPollLog save(SocialDataPollLog entity) {
		final SocialDataPollLog socialDataPollLog = entityRepository.save(entity);
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(socialDataPollLog);
		return socialDataPollLog;
	}
	
	/**
	 * Finds SocialDataPollLog with a given id from persistence store.
	 */
	public SocialDataPollLog findById(final String id) {
		final SocialDataPollLog socialDataPollLog = entityRepository.findById(id);
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(socialDataPollLog);
		return socialDataPollLog;
	}
	
	/**
	 * Reads all the SocialDataPollLog entities from the persistence store with the size limit matching the page request.
	 */
	public Page<SocialDataPollLog> readAll(final PageRequest page) {
		final Page<SocialDataPollLog> entities = entityRepository.findAll(page);
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads all the SocialDataPollLog entities from the persistence store.
	 */
	public List<SocialDataPollLog> fetchAllRecords() {
		final List<SocialDataPollLog> entities = entityRepository.findAll();
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads SocialDataPollLog entities from the persistence store matching a give query.
	 */
	public List<SocialDataPollLog> filter(Query query) {
		final List<SocialDataPollLog> entities = mongoTemplate.find(query, SocialDataPollLog.class);
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Returns count of SocialDataPollLog entities from the persistence store.
	 */
	public Long getCount(Query query) {
		return mongoTemplate.count(query,SocialDataPollLog.class);
	}
	
	/**
	 * Reads SocialDataPollLog from persistence store for a given id.
	 * 
	 * @param entity
	 * @return
	 */
	public SocialDataPollLog read(SocialDataPollLog entity) {
		final SocialDataPollLog socialDataPollLog =  entityRepository.findById(entity.getId());
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(socialDataPollLog);
		return socialDataPollLog;
	}
	
	/**
	 * Updates SocialDataPollLog in persistence store.
	 */
	public SocialDataPollLog update(SocialDataPollLog entity) {
		final SocialDataPollLog socialDataPollLog = entityRepository.save(entity);
		//If needed, enrich data before returning to the business service.
		socialDataPollLogDataEnricher.enrich(socialDataPollLog);
		return socialDataPollLog;
	}
	
	/**
	 * Deletes SocialDataPollLog in persistence store.
	 */
	public Boolean delete(SocialDataPollLog entity) {
		entityRepository.delete(entity);
		return true;
	}
}
