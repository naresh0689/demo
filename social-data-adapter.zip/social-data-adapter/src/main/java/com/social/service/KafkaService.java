package com.social.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Responsible for sending messages to Kafka
 * 
 * 
 * @see SocialDataBusinessRepository
 * 
 * @author Shris Infotech
 */
@Service
public class KafkaService {

	@Value("${kafka.topic.name}")
	private String topicName;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * Publishes given socialData object to Kafka.
	 */
	public boolean publish(final String message) {
		try {
			logger.info("Publishing message : " + message);
			kafkaTemplate.send(topicName, message);
			return true;
		}catch(Exception e) {
			logger.error("Could not publish : " + message + " --> Due to " + e);
			return false;
		}
	}
}
