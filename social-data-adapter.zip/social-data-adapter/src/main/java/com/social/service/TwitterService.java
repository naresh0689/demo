package com.social.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.twitter.api.SearchParameters;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.stereotype.Service;

import com.social.domain.TwitterProfile;

/**
 * Responsible for interacting with twitter and provides methods to get tweets that have been fetched.
 * 
 * 
 * @see SocialDataBusinessRepository
 * 
 * @author Shris Infotech
 */
@Service
public class TwitterService {
	
	@Autowired
	private Twitter twitter;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	/**
	 * Fetch tweets for a given Twitter Profile after a given tweet id.
	 * 
	 * @param twitterProfile
	 * @return
	 */
	public List<Tweet> fetchTweets(final TwitterProfile twitterProfile) {
		logger.info("Getting tweets for  : " + twitterProfile.getHandle());
		SearchParameters sp = new SearchParameters(twitterProfile.getHandle());
		String sinceId = twitterProfile.getLastTweetId();
		logger.info("Last tweet id for  : " + twitterProfile.getHandle() + " is: " + sinceId);
		// Get last tweet id saved for the given hash tag
		if (sinceId != null && !sinceId.isEmpty()) {
			long numSinceId = Long.parseLong(sinceId);
			sp.sinceId(numSinceId);
		}
		return twitter.searchOperations().search(sp).getTweets();
	}
	
	/**
	 * Get max tweet id from the list of tweets
	 * 
	 * @param tweets
	 * @return
	 */
	public long getMaxTweetId(List<Tweet> tweets) {
		if(tweets == null || tweets.isEmpty()) {
			return -1;
		}
		
		long maxTweetId = -1;
		for(Tweet tweet: tweets) {
			maxTweetId = Math.max(maxTweetId, tweet.getId());
		}
		
		return maxTweetId;
	}
	
}
