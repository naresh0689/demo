package com.social.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.stereotype.Service;

import com.social.Application;
import com.social.businessobject.Context;
import com.social.businessobject.SocialDataBusinessLogic;
import com.social.common.JSONUtil;
import com.social.common.QueryFactory;
import com.social.domain.PublishingStatus;
import com.social.domain.SocialData;
import com.social.domain.SocialDataQuery;
import com.social.domain.SocialProfile;
import com.social.domain.SocialSource;
import com.social.domain.TwitterProfile;
import com.social.dto.ResultListDto;
import com.social.repository.SocialDataRepository;
import com.social.repository.TwitterProfileRepository;

import edu.emory.mathcs.backport.java.util.Arrays;

/**
 * Service object for {@link SocialData}
 * 
 * 
 * @see SocialDataRepository
 * @see SocialDataBusinessLogic#perform(MarketData, Context)
 * @see SocialDataBusinessLogic#perform(java.util.Collection, Context)
 * 
 * @author Shris Infotech
 */
@Service
// @CacheConfig(cacheNames = "SocialDatas")
public class SocialDataBusinessService extends GenericBusinessService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	SocialDataDataService socialDataDataService;

	final SocialDataBusinessLogic socialDataBusinessLogic = new SocialDataBusinessLogic();

	@Value("${twitter.handles}")
	private String handles;

	@Value("${watch.folder}")
	private String watchFolder;

	@Autowired
	private SocialProfileBusinessService socialProfileBusinessService;

	@Autowired
	private TwitterService twitterService;

	@Autowired
	private TwitterProfileRepository twitterProfileRepository;

	@Autowired
	private SocialDataRepository socialDataRepository;

	@Autowired
	private KafkaService kafkaService;

	@Autowired
	private SocialDataPollLogBusinessService socialDataPollLogService;

	/**
	 * This method is paginated version of
	 * {@link SocialDataService#fetchAllRecords()}
	 * 
	 * @param page
	 * @return
	 * 
	 * 		TO DO: Add @Cacheable to the method if the objects needs to be
	 *         cached. This needs to work in conjunction with enabling cache. Check
	 *         {@link Application} for cache configuration. Ex: @Cacheable(unless =
	 *         "#result != null and #result.size() == 0")
	 */
	public Page<SocialData> readAll(final PageRequest page) {
		final Page<SocialData> entities = socialDataDataService.readAll(page);
		socialDataBusinessLogic.perform(entities.getContent(), Context.GET);
		return entities;
	}

	/**
	 * Reads SocialData entities from the persistence store matching a give query.
	 */
	public ResultListDto<SocialData> filter(final SocialDataQuery socialDataQuery) {

		Criteria criteria = null;

		criteria = Criteria.where("user").is(socialDataQuery.getUser());

		if (socialDataQuery.getSource() != null) {
			criteria = criteria.and("source").in(Arrays.asList(socialDataQuery.getSource()));
		}

		if (socialDataQuery.getStartDate() != null && socialDataQuery.getEndDate() != null) {
			criteria = criteria.and("createdDate").gte(socialDataQuery.getStartDate())
					.lte(socialDataQuery.getEndDate());
		}

		Query query = QueryFactory.createSimpleQuery();
		if (criteria != null) {
			query.addCriteria(criteria);
		}

		return socialDataDataService.filter(query, socialDataQuery.getPageNumber(), socialDataQuery.getPageSize());
	}

	/**
	 * Fetches all the entities of type {@link SocialData} from the data base.
	 * 
	 * @return
	 * 
	 * 		TO DO: Add @Cacheable to the method if the objects needs to be
	 *         cached. This needs to work in conjunction with enabling cache. Check
	 *         {@link Application} for cache configuration. Ex: @Cacheable(unless =
	 *         "#result != null and #result.size() == 0")
	 */
	public List<SocialData> fetchAllRecords() {
		final List<SocialData> entities = socialDataDataService.fetchAllRecords();
		socialDataBusinessLogic.perform(entities, Context.GET);
		return entities;
	}

	/**
	 *
	 * Finds list of {@link SocialData} objects matching given query.
	 * 
	 * @param query
	 * @return
	 */
	public List<SocialData> filter(Query query) {
		final List<SocialData> entities = socialDataDataService.filter(query);
		socialDataBusinessLogic.perform(entities, Context.FIND);
		return entities;
	}

	/**
	 * Returns count of {@link SocialData} objects matching a given query.
	 * 
	 * @param query
	 * @return count
	 */
	public Long getCount(Query query) {
		return socialDataDataService.getCount(query);
	}

	/**
	 *
	 * Returns details of {@link SocialData} object for a given id.
	 * 
	 * @param emp
	 * @return
	 */
	public SocialData read(SocialData entity) {
		socialDataBusinessLogic.perform(entity, Context.GET);
		return socialDataDataService.read(entity);
	}

	/**
	 * Executes business logic on {@link SocialData} and persists it to the DB.
	 * 
	 * @param entity
	 *            Entity to persist in the DB
	 * @return newly created {@link SocialData}
	 * 
	 *         TO DO: Add @CachePut to the method if the object needs to be cached.
	 *         This needs to work in conjunction with enabling cache. Check
	 *         {@link Application} for cache configuration.
	 */
	public SocialData create(SocialData entity) {
		socialDataBusinessLogic.perform(entity, Context.CREATE);
		return socialDataDataService.save(entity);
	}

	/**
	 * 
	 * Updates an existing {@link SocialData} in the database.
	 * 
	 * 
	 * @param entity
	 * @return
	 * 
	 * 		TO DO: If the {@link SocialData} is cached, update the cache as well.
	 */
	public SocialData update(SocialData entity) {
		SocialData existingEntity = socialDataDataService.findById(entity.getId());

		if (existingEntity == null) {
			logger.error("Cannot update SocialData. No entity with id " + entity.getId() + " exists");
			throw new IllegalArgumentException(
					"Cannot update SocialData. No entity with id " + entity.getId() + " exists");
		}
		socialDataBusinessLogic.perform(entity, Context.UPDATE);
		return socialDataDataService.save(entity);
	}

	/**
	 * 
	 * Deletes an existing {@link SocialData} from the database.
	 * 
	 * 
	 * @param entity
	 * @return
	 * 
	 * 		TO DO: If the {@link SocialData} is cached, delete from cache as
	 *         well. Ex: @CacheEvict
	 */
	public Boolean delete(SocialData entity) {
		SocialData existingEntity = socialDataDataService.findById(entity.getId());

		if (existingEntity == null) {
			logger.error("Cannot delete SocialData. No entity with id " + entity.getId() + " exists");
			throw new IllegalArgumentException(
					"Cannot delete SocialData. No entity with id " + entity.getId() + " exists");
		}
		super.preDelete(entity);
		socialDataBusinessLogic.perform(entity, Context.DELETE);
		socialDataDataService.delete(existingEntity);
		super.postDelete(entity);
		return true;
	}

	/**
	 * Fetches tweets for all the active user profiles.
	 */
	@Scheduled(fixedDelayString = "${twitter.fetch.interval.ms}")
	public void fetchAndPersistTweets() {
		logger.info("Started running the job. Getting tweets.");
		List<SocialProfile> activeSocialProfiles = socialProfileBusinessService.findActiveSocialProfiles();
		// No social profiles to process
		if (activeSocialProfiles == null || activeSocialProfiles.isEmpty()) {
			return;
		}

		for (SocialProfile socialProfile : activeSocialProfiles) {
			List<Tweet> tweets = twitterService.fetchTweets(socialProfile.getTwitterProfile());
			// Continue when there are no tweets
			if (tweets == null || tweets.isEmpty()) {
				logger.info("No new tweets for the handle: " + socialProfile.getTwitterProfile().getHandle());
				persistSocialDataPollLog(SocialSource.Twitter, socialProfile.getUserId(), Boolean.FALSE);
				continue;
			}

			// Get max tweet Id
			long maxTweetid = twitterService.getMaxTweetId(tweets);
			// Get social data objects for the tweets.
			List<SocialData> socialData = getSocialData(socialProfile.getUserId(), tweets);
			// ! Persist Social Data !
			socialDataDataService.saveAll(socialData);
			logger.info("Persisted social data for handle: " + socialProfile.getTwitterProfile().getHandle());
			// ! Persist updated max tweet id in Twitter Profile !
			final TwitterProfile twitterProfile = socialProfile.getTwitterProfile();
			twitterProfile.setLastTweetId(maxTweetid);
			twitterProfileRepository.save(twitterProfile);
			logger.info("Updated social data for handle: " + socialProfile.getTwitterProfile().getHandle());
			persistSocialDataPollLog(SocialSource.Twitter, socialProfile.getUserId(), Boolean.TRUE);
		}
		logger.info("End of running the job");
	}

	/**
	 * Publishes social data fetched to Kafka and updated the the DB messages as
	 * published.
	 */
	@Scheduled(fixedDelayString = "${social.data.publish.interval.ms}")
	public void publishTweets() {
		logger.info("Start of social data publishing job");
		List<SocialData> unpublishedTweets = socialDataRepository.findByStatus(PublishingStatus.N);
		if (unpublishedTweets == null || unpublishedTweets.isEmpty()) {
			return;
		}
		logger.info("Got unpublished messages");
		// Mark messages picked for publishing to M so that no other jon pickes them
		// again.
		for (SocialData socialData : unpublishedTweets) {
			socialData.setStatus(PublishingStatus.M);
		}
		// ! Persist the updated status !
		socialDataRepository.save(unpublishedTweets);
		logger.info("Marked unpublished messages to M");

		for (SocialData socialData : unpublishedTweets) {
			String message = getJSON(socialData);
			boolean isSuccessful = kafkaService.publish(message);
			logger.info("Sent Kafka message for message: " + message);
			PublishingStatus status = isSuccessful == true ? PublishingStatus.P : PublishingStatus.N;
			socialData.setStatus(status);
			socialDataRepository.save(socialData);
			logger.info("Updated status in DB after publishing to kafka for: " + message);
		}

	}

	/**
	 * Persist SocialDataPollLog
	 * 
	 * @param source
	 * @param user
	 * @param dataFetched
	 */
	private void persistSocialDataPollLog(SocialSource source, String user, Boolean dataFetched) {
		/*SocialDataPollLog socialDataPollLog = new SocialDataPollLog();
		socialDataPollLog.setSource(source);
		socialDataPollLog.setUser(user);
		socialDataPollLog.setIsNewDataFetched(dataFetched);
		socialDataPollLog.setCreatedDate(new Date());
		socialDataPollLogService.create(socialDataPollLog);*/
	}

	/**
	 * Watches messages dropped in a folder.
	 */
	@Scheduled(fixedDelayString = "${watch.folder.interval.ms}")
	public void watchMessages() {
		
		// Watch any new messages in folder
		File watchFile = new File(watchFolder);
		File[] matchingFiles = watchFile.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith("json");
			}
		});

		if (matchingFiles == null || matchingFiles.length == 0) {
			return;
		}

		// If there is any new message persist it
		for (File jsonFile : matchingFiles) {
			try {
				FileInputStream fis = new FileInputStream(jsonFile);
				byte[] data = new byte[(int) jsonFile.length()];
				fis.read(data);
				fis.close();
				SocialData socialData = JSONUtil.getEntityFromJson(SocialData.class, new String(data));
				// ! Persist Social Data!
				socialDataDataService.save(socialData);
				// Remove the message from the folder
				jsonFile.delete();
			} catch (IOException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
	}

	private String getJSON(Object object) {
		try {
			return JSONUtil.getJsonFromEntity(object);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		}
	}

	public String[] getHandles() {
		return handles.split(",");
	}

	public SocialData getSocialData(final String user, final Tweet tweet) {
		SocialData socialData = new SocialData();
		socialData.setRawMessage(getJSON(tweet));
		socialData.setSource(com.social.domain.SocialSource.Twitter);
		socialData.setUser(user);
		return socialData;
	}

	public List<SocialData> getSocialData(final String user, final List<Tweet> tweets) {

		if (tweets == null || tweets.isEmpty()) {
			return Collections.EMPTY_LIST;
		}

		final List<SocialData> socialDataList = new ArrayList<SocialData>();
		for (Tweet tweet : tweets) {
			socialDataList.add(getSocialData(user, tweet));
		}

		return socialDataList;
	}
}
