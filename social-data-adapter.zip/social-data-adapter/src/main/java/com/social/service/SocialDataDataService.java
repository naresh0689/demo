package com.social.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.context.MessageSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.social.domain.SocialData;
import com.social.dto.ResultListDto;
import com.social.repository.SocialDataRepository;
import com.social.businessobject.SocialDataBusinessLogic;
import com.social.businessobject.SocialDataDataEnricher;
import com.social.businessobject.Context;

/**
 * Service object for {@link SocialData}
 * 
 * 
 * @see SocialDataRepository
 * @see SocialDataBusinessLogic#perform(SocialData, Context)
 * @see SocialDataBusinessLogic#perform(java.util.Collection, Context)
 * 
 * @author Shris Infotech
 */
@Service
public class SocialDataDataService extends GenericDataService{

	@Autowired
	private SocialDataRepository entityRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	private SocialDataDataEnricher socialDataDataEnricher = new SocialDataDataEnricher();
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	/**
	 * Saves SocialData to persistence store.
	 */
	public SocialData save(SocialData entity) {
		final SocialData socialData = entityRepository.save(entity);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(socialData);
		return socialData;
	}
	
	/**
	 * Saves SocialData to persistence store.
	 */
	public List<SocialData> saveAll(List<SocialData> entityList) {
		 List<SocialData> socialData = entityRepository.save(entityList);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(socialData);
		return socialData;
	}
	
	/**
	 * Finds SocialData with a given id from persistence store.
	 */
	public SocialData findById(final String id) {
		final SocialData socialData = entityRepository.findById(id);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(socialData);
		return socialData;
	}
	
	/**
	 * Reads all the SocialData entities from the persistence store with the size limit matching the page request.
	 */
	public Page<SocialData> readAll(final PageRequest page) {
		final Page<SocialData> entities = entityRepository.findAll(page);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads all the SocialData entities from the persistence store.
	 */
	public List<SocialData> fetchAllRecords() {
		final List<SocialData> entities = entityRepository.findAll();
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads SocialData entities from the persistence store matching a give query.
	 */
	public List<SocialData> filter(Query query) {
		final List<SocialData> entities = mongoTemplate.find(query, SocialData.class);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(entities);
		return entities;
	}
	
	/**
	 * Reads SocialData entities from the persistence store matching a give query.
	 */
	public ResultListDto<SocialData> filter(Query query, int pageNumber, int pageSize) {
		
		final Pageable pageableRequest = new PageRequest(pageNumber, pageSize);
		query.with(pageableRequest);
		
		Long count = entityRepository.count();
		final List<SocialData> entities = mongoTemplate.find(query, SocialData.class);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(entities);
		
		ResultListDto<SocialData> resultListDto = new ResultListDto<SocialData>();
		resultListDto.setResultList(entities);
		resultListDto.setPageCount(pageSize);
		resultListDto.setTotalCount(count);
		resultListDto.setCurrentPage(pageNumber);
		
		return resultListDto;
	}
	
	/**
	 * Returns count of SocialData entities from the persistence store.
	 */
	public Long getCount(Query query) {
		return mongoTemplate.count(query,SocialData.class);
	}
	
	/**
	 * Reads SocialData from persistence store for a given id.
	 * 
	 * @param entity
	 * @return
	 */
	public SocialData read(SocialData entity) {
		final SocialData socialData =  entityRepository.findById(entity.getId());
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(socialData);
		return socialData;
	}
	
	/**
	 * Updates SocialData in persistence store.
	 */
	public SocialData update(SocialData entity) {
		final SocialData socialData = entityRepository.save(entity);
		//If needed, enrich data before returning to the business service.
		socialDataDataEnricher.enrich(socialData);
		return socialData;
	}
	
	/**
	 * Deletes SocialData in persistence store.
	 */
	public Boolean delete(SocialData entity) {
		entityRepository.delete(entity);
		return true;
	}
	
	
}
