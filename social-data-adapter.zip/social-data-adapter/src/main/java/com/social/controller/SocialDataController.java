package com.social.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.social.businessobject.SocialDataBusinessLogic;
import com.social.common.QueryUtil;
import com.social.domain.SocialData;
import com.social.domain.SocialDataQuery;
import com.social.dto.ResultListDto;
import com.social.service.SocialDataBusinessService;
import com.social.validator.SocialDataValidator;
	
	/**
	 * REST controller for {@link SocialData} domain object.
	 * 
	 * 
	 * 
	 * @see SocialData
	 * @see SocialDataBusinessLogic#perform(SocialData, com.social.businessobject.Context)
	 * @see SocialDataValidator#validate(Object, org.springframework.validation.Errors)
	 * @see SocialDataBusinessLogic#perform(java.util.Collection, com.social.businessobject.Context)
	 * @see ResultListDto
	 *
	 * @author Shris Infotech
	 */
	 
	@Controller
	@RequestMapping("/socialData")
	public class SocialDataController {

		@Autowired
		private SocialDataBusinessService service;
		
		@Autowired
		private QueryUtil queryUtil;
		
		@Autowired
		private SocialDataValidator socialDataValidator;
		
		private final Logger logger = LoggerFactory.getLogger(this.getClass());
		
		@InitBinder
		protected void initBinder(WebDataBinder binder) {
	    	binder.setValidator(socialDataValidator);
		}
	
		/**
		 * This method is paginated version of {@link SocialDataController#fetchAllRecords()}
		 * 
		 * @return
		 * 
		 */
		@PreAuthorize("hasAuthority('Admin')")
		@RequestMapping(value = "/records/{page}/{pageSize}")
		public @ResponseBody ResultListDto<SocialData> getAllRecords(@PathVariable("page") int page,@PathVariable("pageSize") int pageSize) {
			pageSize = queryUtil.getPageSize(pageSize);
	    		final PageRequest pageRequest = new PageRequest(page, pageSize,Sort.Direction.DESC,"createdDate");
	    		ResultListDto<SocialData> resultListDto = new ResultListDto<SocialData>();
			Page<SocialData> pageList = service.readAll(pageRequest);
			resultListDto.setResultList(pageList.getContent());
			resultListDto.setPageCount(pageList.getTotalPages());
			resultListDto.setTotalCount(pageList.getTotalElements());
			resultListDto.setCurrentPage(page);
			return resultListDto;
		}
		
		/**
		 * This method is paginated version of {@link SocialDataController#fetchAllRecords()}
		 * 
		 * @return
		 * 
		 */
		@PreAuthorize("hasAuthority('Admin')")
		@RequestMapping(value = "{user}", method = RequestMethod.POST)
		public @ResponseBody ResultListDto<SocialData> filter(@PathVariable("user") String user, @RequestBody(required=false) SocialDataQuery socialDataQuery) {
			if(socialDataQuery == null) {
				socialDataQuery = new SocialDataQuery();
			}
			socialDataQuery.setUser(user);
			return service.filter(socialDataQuery);
		}
		
		
		/**
		 * Creates new {@link SocialData} in the database.
		 * 
		 * @param entity
		 * @return Newly created {@link SocialData} object
		 * 
		 *
		 */
		@PreAuthorize("hasAuthority('Admin')")
		@RequestMapping(method = RequestMethod.POST)
		public @ResponseBody SocialData create(@Valid @RequestBody SocialData entity) {
			logger.info("Creating a new SocialData: ");
			return service.create(entity);
		}
	
		/**
		 * Updates an existing {@link SocialData} in the database.
		 * 
		 * @param entity {@link SocialData} to update
		 * @return Updated {@link SocialData} object
		 * 
		 *
		 */
		@PreAuthorize("hasAuthority('Admin')")
		@RequestMapping(method = RequestMethod.PUT)
		public @ResponseBody SocialData update(@Valid @RequestBody SocialData entity) {
			logger.info("Update SocialData: ");
			return service.update(entity);
		}

       
		
		/**
		 * Deletes an existing {@link MarketData} from the database.
		 * 
		 * @param id {@link MarketData} object with the matching id passed in will be deleted..
		 * @return
		 * 
		 */
		@PreAuthorize("hasAuthority('Admin')")
		@RequestMapping(method = RequestMethod.DELETE)
		public @ResponseBody Boolean delete(@RequestParam String id) {
			SocialData socialData = new SocialData();
			socialData.setId(id);
			logger.info("Delete SocialData: ");
			return service.delete(socialData);
		}
	}


