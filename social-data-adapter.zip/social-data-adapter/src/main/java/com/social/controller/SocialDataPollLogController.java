package com.social.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.social.businessobject.SocialDataPollLogBusinessLogic;
import com.social.common.QueryUtil;
import com.social.domain.SocialDataPollLog;
import com.social.dto.ResultListDto;
import com.social.service.SocialDataPollLogBusinessService;
import com.social.validator.SocialDataPollLogValidator;

/**
 * REST controller for {@link SocialDataPollLog} domain object.
 * 
 * 
 * 
 * @see SocialDataPollLog
 * @see SocialDataPollLogBusinessLogic#perform(SocialDataPollLog,
 *      com.social.businessobject.Context)
 * @see SocialDataPollLogValidator#validate(Object,
 *      org.springframework.validation.Errors)
 * @see SocialDataPollLogBusinessLogic#perform(java.util.Collection,
 *      com.social.businessobject.Context)
 * @see ResultListDto
 *
 * @author Shris Infotech
 */

@Controller
@RequestMapping("/socialDataPollLog")
public class SocialDataPollLogController {

	@Autowired
	private SocialDataPollLogBusinessService service;

	@Autowired
	private QueryUtil queryUtil;

	@Autowired
	private SocialDataPollLogValidator socialDataPollLogValidator;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(socialDataPollLogValidator);
	}

	/**
	 * This method is paginated version of
	 * {@link SocialDataPollLogController#fetchAllRecords()}
	 * 
	 * @return
	 * 
	 */
	@PreAuthorize("hasAuthority('Admin')")
	@RequestMapping(value = "/records/{page}/{pageSize}")
	public @ResponseBody ResultListDto<SocialDataPollLog> getAllRecords(@PathVariable("page") int page,
			@PathVariable("pageSize") int pageSize) {

		pageSize = queryUtil.getPageSize(pageSize);
		final PageRequest pageRequest = new PageRequest(page, pageSize, Sort.Direction.DESC, "createdDate");
		ResultListDto<SocialDataPollLog> resultListDto = new ResultListDto<SocialDataPollLog>();

		Page<SocialDataPollLog> pageList = service.readAll(pageRequest);
		resultListDto.setResultList(pageList.getContent());
		resultListDto.setPageCount(pageList.getTotalPages());
		resultListDto.setTotalCount(pageList.getTotalElements());
		resultListDto.setCurrentPage(page);
		return resultListDto;
	}
}
