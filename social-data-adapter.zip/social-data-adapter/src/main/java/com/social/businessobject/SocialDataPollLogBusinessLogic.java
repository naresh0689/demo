package com.social.businessobject;

import com.social.domain.SocialDataPollLog;
import java.util.UUID;
import java.util.Collection;

/**
 * Performs business logic for SocialDataPollLog.
 * 
 * 
 * @see Context
 * @see SocialDataPollLog
 * @see SocialDataPollLogBusinessService#create(SocialDataPollLog)
 * @see SocialDataPollLogBusinessService#update(SocialDataPollLog)
 * @see SocialDataPollLogBusinessService#delete(SocialDataPollLog)
 *
 * @author Shris Infotech
 */
public class SocialDataPollLogBusinessLogic {
	
	/**
	 * Implements business logic for {@link SocialDataPollLog}
	 * 
	 * @param entity
	 * @param context
	 */	
	public void perform(final SocialDataPollLog socialDataPollLog, final Context context) {
		// Perform your business logic here.
		// Ex: If a and b are part of the incoming object and if we have to do a a+ b and assign to c. it has to be done here.
		if(Context.CREATE.equals(context)) {
			// Logic that needs to be performed during creation of the object
			final String textId = UUID.randomUUID().toString();
			socialDataPollLog.setId(textId);
		} else if(Context.UPDATE.equals(context)) {
			// Logic that needs to be performed during update of the object
		} else if(Context.DELETE.equals(context)) {
			// Logic that needs to be performed during delete of the object
		} else if(Context.GET.equals(context)) {
			// Logic that needs to be performed during get operation
		} else if(Context.FIND.equals(context)) {
			// Logic that needs to be performed during the find operation
		}
	}
	
	/**
	 * Implements business logic for a collection of {@link Ticker} objects
	 * 
	 * @param entityCollection
	 * @param context
	 */
	public void perform(final Collection<SocialDataPollLog> socialDataPollLogCollection, final Context context) {
		if(socialDataPollLogCollection != null && !socialDataPollLogCollection.isEmpty()) {
			for (final SocialDataPollLog entity : socialDataPollLogCollection) {
				perform(entity, context);
			}
		}
	}
	
}