package com.social.businessobject;

import java.util.Collection;

import org.springframework.data.domain.Page;

import com.social.domain.SocialData;
import com.social.service.SocialDataDataService;

/**
 * Enriches data before returning domain objects of type Doctor to the business service layer.
 * 
 * Examples for data enrichment:
 * -----------------------------
 * 1. Conversion of date format
 * 2. Currency conversions
 * 3. Populating salutations based on Gender
 * 4. Converting case of a string (Like upper to lower - lower to upper) etc...
 *  
 * @see SocialDataDataService
 * @author Shris Infotech
 * 
 */
public class SocialDataDataEnricher {
	
	/**
	 * Enriches socialDatas domain object.
	 * 
	 * @param socialData
	 */
	public void enrich(final SocialData socialData) {
		// TO DO: Enrich the data
		// 
	}
	
	/**
	 * Enriches collection of socialDatas domain objects.
	 * 
	 * @param socialDatas
	 */
	public void enrich(final Collection<SocialData> socialDatas) {
		if(socialDatas == null || socialDatas.isEmpty()) {
			return;
		}
		for (SocialData socialData : socialDatas) {
			enrich(socialData);
		}
	}
	
	/**
	 * Enriches Page set of doctor domain objects.
	 * 
	 * @param entities
	 */
	public void enrich(Page<SocialData> entities) {
		if(entities == null) {
			return;
		}
		
		for (SocialData socialData : entities) {
			enrich(socialData);
		}
	}
	
}
