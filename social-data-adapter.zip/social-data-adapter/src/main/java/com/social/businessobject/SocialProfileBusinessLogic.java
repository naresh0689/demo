package com.social.businessobject;

import com.social.domain.SocialProfile;
import java.util.UUID;
import java.util.Collection;

/**
 * Performs business logic for SocialProfile.
 * 
 * 
 * @see Context
 * @see SocialProfile
 * @see SocialProfileBusinessService#create(SocialProfile)
 * @see SocialProfileBusinessService#update(SocialProfile)
 * @see SocialProfileBusinessService#delete(SocialProfile)
 *
 * @author Shris Infotech
 */
public class SocialProfileBusinessLogic {
	
	/**
	 * Implements business logic for {@link SocialProfile}
	 * 
	 * @param entity
	 * @param context
	 */	
	public void perform(final SocialProfile socialProfile, final Context context) {
		// Perform your business logic here.
		// Ex: If a and b are part of the incoming object and if we have to do a a+ b and assign to c. it has to be done here.
		if(Context.CREATE.equals(context)) {
			// Logic that needs to be performed during creation of the object
			final String textId = UUID.randomUUID().toString();
			if(socialProfile.getId() == null || socialProfile.getId().equals("")) {
				socialProfile.setId(textId);
			}
			if(socialProfile.getUserId() == null) {
				socialProfile.setUserId(UUID.randomUUID().toString());
			}	
		} else if(Context.UPDATE.equals(context)) {
			// Logic that needs to be performed during update of the object
		} else if(Context.DELETE.equals(context)) {
			// Logic that needs to be performed during delete of the object
		} else if(Context.GET.equals(context)) {
			// Logic that needs to be performed during get operation
		} else if(Context.FIND.equals(context)) {
			// Logic that needs to be performed during the find operation
		}
	}
	
	/**
	 * Implements business logic for a collection of {@link Ticker} objects
	 * 
	 * @param entityCollection
	 * @param context
	 */
	public void perform(final Collection<SocialProfile> socialProfileCollection, final Context context) {
		if(socialProfileCollection != null && !socialProfileCollection.isEmpty()) {
			for (final SocialProfile entity : socialProfileCollection) {
				perform(entity, context);
			}
		}
	}
	
}