package com.social.businessobject;

import java.util.Collection;

import org.springframework.data.domain.Page;

import com.social.domain.SocialProfile;
import com.social.service.SocialProfileDataService;

/**
 * Enriches data before returning domain objects of type Doctor to the business service layer.
 * 
 * Examples for data enrichment:
 * -----------------------------
 * 1. Conversion of date format
 * 2. Currency conversions
 * 3. Populating salutations based on Gender
 * 4. Converting case of a string (Like upper to lower - lower to upper) etc...
 *  
 * @see SocialProfileDataService
 * @author Shris Infotech
 * 
 */
public class SocialProfileDataEnricher {
	
	/**
	 * Enriches socialProfiles domain object.
	 * 
	 * @param socialProfile
	 */
	public void enrich(final SocialProfile socialProfile) {
		// TO DO: Enrich the data
		// 
	}
	
	/**
	 * Enriches collection of socialProfiles domain objects.
	 * 
	 * @param socialProfiles
	 */
	public void enrich(final Collection<SocialProfile> socialProfiles) {
		if(socialProfiles == null || socialProfiles.isEmpty()) {
			return;
		}
		for (SocialProfile socialProfile : socialProfiles) {
			enrich(socialProfile);
		}
	}
	
	/**
	 * Enriches Page set of doctor domain objects.
	 * 
	 * @param entities
	 */
	public void enrich(Page<SocialProfile> entities) {
		if(entities == null) {
			return;
		}
		
		for (SocialProfile socialProfile : entities) {
			enrich(socialProfile);
		}
	}
	
}
