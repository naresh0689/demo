package com.social.businessobject;

import java.util.Collection;

import org.springframework.data.domain.Page;

import com.social.domain.SocialDataPollLog;
import com.social.service.SocialDataPollLogDataService;

/**
 * Enriches data before returning domain objects of type Doctor to the business service layer.
 * 
 * Examples for data enrichment:
 * -----------------------------
 * 1. Conversion of date format
 * 2. Currency conversions
 * 3. Populating salutations based on Gender
 * 4. Converting case of a string (Like upper to lower - lower to upper) etc...
 *  
 * @see SocialDataPollLogDataService
 * @author Shris Infotech
 * 
 */
public class SocialDataPollLogDataEnricher {
	
	/**
	 * Enriches socialDataPollLogs domain object.
	 * 
	 * @param socialDataPollLog
	 */
	public void enrich(final SocialDataPollLog socialDataPollLog) {
		// TO DO: Enrich the data
		// 
	}
	
	/**
	 * Enriches collection of socialDataPollLogs domain objects.
	 * 
	 * @param socialDataPollLogs
	 */
	public void enrich(final Collection<SocialDataPollLog> socialDataPollLogs) {
		if(socialDataPollLogs == null || socialDataPollLogs.isEmpty()) {
			return;
		}
		for (SocialDataPollLog socialDataPollLog : socialDataPollLogs) {
			enrich(socialDataPollLog);
		}
	}
	
	/**
	 * Enriches Page set of doctor domain objects.
	 * 
	 * @param entities
	 */
	public void enrich(Page<SocialDataPollLog> entities) {
		if(entities == null) {
			return;
		}
		
		for (SocialDataPollLog socialDataPollLog : entities) {
			enrich(socialDataPollLog);
		}
	}
	
}
