package com.social.businessobject;

import com.social.domain.SocialData;
import java.util.UUID;
import java.util.Collection;

/**
 * Performs business logic for SocialData.
 * 
 * 
 * @see Context
 * @see SocialData
 * @see SocialDataBusinessService#create(SocialData)
 * @see SocialDataBusinessService#update(SocialData)
 * @see SocialDataBusinessService#delete(SocialData)
 *
 * @author Shris Infotech
 */
public class SocialDataBusinessLogic {
	
	/**
	 * Implements business logic for {@link SocialData}
	 * 
	 * @param entity
	 * @param context
	 */	
	public void perform(final SocialData socialData, final Context context) {
		// Perform your business logic here.
		// Ex: If a and b are part of the incoming object and if we have to do a a+ b and assign to c. it has to be done here.
		if(Context.CREATE.equals(context)) {
			// Logic that needs to be performed during creation of the object
			final String textId = UUID.randomUUID().toString();
			socialData.setId(textId);
		} else if(Context.UPDATE.equals(context)) {
			// Logic that needs to be performed during update of the object
		} else if(Context.DELETE.equals(context)) {
			// Logic that needs to be performed during delete of the object
		} else if(Context.GET.equals(context)) {
			// Logic that needs to be performed during get operation
		} else if(Context.FIND.equals(context)) {
			// Logic that needs to be performed during the find operation
		}
	}
	
	/**
	 * Implements business logic for a collection of {@link Ticker} objects
	 * 
	 * @param entityCollection
	 * @param context
	 */
	public void perform(final Collection<SocialData> socialDataCollection, final Context context) {
		if(socialDataCollection != null && !socialDataCollection.isEmpty()) {
			for (final SocialData entity : socialDataCollection) {
				perform(entity, context);
			}
		}
	}
	
}