package com.social.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.social.domain.SocialData; 

@Configuration
public class KafkaConfig {

	@Value(value = "${kafka.bootstrapAddress}")
	private String bootstrapAddress;

	/**
	 * Creates ProducerFactory Bean to send messages whose Key and Values are of
	 * type String.
	 * 
	 * @return ProducerFactory
	 */
	@Bean
	public ProducerFactory<String, String> producerFactory() {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		//configProps.put(ProducerConfig.RETRIES_CONFIG, 1);
		configProps.put(ProducerConfig.BATCH_SIZE_CONFIG, 5);
		configProps.put(ProducerConfig.LINGER_MS_CONFIG, 1);
		return new DefaultKafkaProducerFactory<>(configProps);
	}

	/**
	 * Creates ProducerFactory Bean to send messages whose Key is of type String and
	 * whose value is of Message pojo type.
	 * 
	 * @return
	 */
	@Bean
	public ProducerFactory<String, SocialData> pojoMessageProducerFactory() {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		return new DefaultKafkaProducerFactory<>(configProps);
	}

	/**
	 * Creates KafkaTemplate bean. This is the class on which one calls methods to
	 * send messages of type <String,String> to Kafka.
	 * 
	 * @return
	 */
	@Bean
	public KafkaTemplate<String, String> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}

	/**
	 * Creates KafkaTemplate bean. This is the class on which one calls methods to
	 * send messages of type <String,Message> to Kafka.
	 * 
	 * @return
	 */
	@Bean
	public KafkaTemplate<String, SocialData> pojoKafkaTemplate() {
		return new KafkaTemplate<>(pojoMessageProducerFactory());
	}

}
