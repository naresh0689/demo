package com.social.test.controller;

import org.junit.Test;

/**
 * Tests to verify CRUD operations on SocialDataPollLog
 * 
 * @author Shris Infotech
 *
 */
public class SocialDataPollLogControllerTest {
	
	@Test
	public void createSocialDataPollLogTest() {
		
	}
	
	@Test
	public void updateSocialDataPollLogTest() {
		
	}
	
	@Test
	public void deleteSocialDataPollLogTest() {
		
	}
	
	@Test
	public void readSocialDataPollLogTest() {
		
	}
	
	@Test
	public void searchSocialDataPollLogTest() {
		
	}
}
