package com.social.test.controller;

import org.junit.Test;

/**
 * Tests to verify CRUD operations on SocialProfile
 * 
 * @author Shris Infotech
 *
 */
public class SocialProfileControllerTest {
	
	@Test
	public void createSocialProfileTest() {
		
	}
	
	@Test
	public void updateSocialProfileTest() {
		
	}
	
	@Test
	public void deleteSocialProfileTest() {
		
	}
	
	@Test
	public void readSocialProfileTest() {
		
	}
	
	@Test
	public void searchSocialProfileTest() {
		
	}
}
