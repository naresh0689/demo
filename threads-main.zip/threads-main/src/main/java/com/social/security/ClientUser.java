package com.social.security;

import java.util.LinkedList;

public class ClientUser {

	private String id;
	private String userId;
	private String firstName;
	private String lastName;
	private String userName;
	private LinkedList<String> authList;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public LinkedList<String> getAuthList() {
		return authList;
	}

	public void setAuthList(LinkedList<String> authList) {
		this.authList = authList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
