package com.social.test.controller;

import org.junit.Test;

/**
 * Tests to verify CRUD operations on SocialData
 * 
 * @author Shris Infotech
 *
 */
public class SocialDataControllerTest {
	
	@Test
	public void createSocialDataTest() {
		
	}
	
	@Test
	public void updateSocialDataTest() {
		
	}
	
	@Test
	public void deleteSocialDataTest() {
		
	}
	
	@Test
	public void readSocialDataTest() {
		
	}
	
	@Test
	public void searchSocialDataTest() {
		
	}
}
