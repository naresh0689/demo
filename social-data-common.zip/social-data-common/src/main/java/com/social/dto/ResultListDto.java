package com.social.dto;

import java.util.List;

/**
 * Used as data transfer object for all the DB operations.
 * 
 * 
 * @param <T>
 *
 * @author Shris Infotech
 */
 
public class ResultListDto<T> {


	private List<T> resultList;
	private int pageCount;
	private int currentPage;
	private long totalCount;
	
	public List<T> getResultList() {
		return resultList;
	}
	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
}
