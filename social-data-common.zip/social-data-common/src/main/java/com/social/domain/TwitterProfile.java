package com.social.domain;

import org.springframework.data.annotation.Id;

public class TwitterProfile {
	
	/**
	 * Handle of the user.
	 */
	@Id
	private String handle;
	
	/**
	 * Hash tag of the user.
	 */
	private String lastTweetId;
	
	/**
	 * Flag to indicate if a user is a active twitter user or not in the context of the system.
	 */
	private boolean isActive = true;

	public  TwitterProfile() {}
	public  TwitterProfile(String handle) {
		this.handle = handle;
	}

	public String getHandle() {
		return handle;
	}

	public void setHandle(String handle) {
		this.handle = handle;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getLastTweetId() {
		return lastTweetId;
	}

	public void setLastTweetId(String lastTweetId) {
		this.lastTweetId = lastTweetId;
	}
	
	public void setLastTweetId(long lastTweetId) {
		this.lastTweetId = String.valueOf(lastTweetId);
	}
}
