package com.social.domain;

public enum SocialSource {
	Twitter, Facebook, LinkedIn
}
