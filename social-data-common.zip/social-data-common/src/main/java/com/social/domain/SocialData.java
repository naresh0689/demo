package com.social.domain;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

// Imports
import com.social.domain.core.BaseDomain;
import com.social.domain.core.annotation.Auditable;
import com.social.domain.core.annotation.Required;
@Auditable
@JsonIgnoreProperties(ignoreUnknown = true)
public class SocialData extends BaseDomain{
		// Field declarations
		// ------------------
		@Required
		private String user;
		@Required
		private String rawMessage;
		private String message;
		@Required
		private SocialSource source;
		private PublishingStatus status = PublishingStatus.N;
		
		// Getters and Setters
		// ------------------
		public String getUser() {
			return this.user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public String getRawMessage() {
			return this.rawMessage;
		}
		public void setRawMessage(String rawMessage) {
			this.rawMessage = rawMessage;
		}
		
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public SocialSource getSource() {
			return this.source;
		}
		public void setSource(SocialSource source) {
			this.source = source;
		}
		public PublishingStatus getStatus() {
			return status;
		}
		public void setStatus(PublishingStatus status) {
			this.status = status;
		}
}
