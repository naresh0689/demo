package com.social.domain;

import java.util.Date;

import com.social.common.CommonUtil;

public class SocialDataQuery {
	
	private String user;
	private String[] source;
	private Date startDate = CommonUtil.getStartOfDay(new Date());
	private Date endDate = new Date();
	private int pageNumber = 0;
	private int pageSize = 10;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	public String[] getSource() {
		return source;
	}
	public void setSource(String[] source) {
		this.source = source;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
