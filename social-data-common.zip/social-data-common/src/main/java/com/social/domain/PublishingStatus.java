package com.social.domain;

public enum PublishingStatus {
	// N = Not Published.
	// M = Marked for publishing.
	// P = Published.
	N, M, P
}
