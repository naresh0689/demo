package com.social.domain;
// Imports
import com.social.domain.core.BaseDomain;
import com.social.domain.core.annotation.Required;

public class SocialDataPollLog extends BaseDomain{
		// Field declarations
		// ------------------
		@Required
		private SocialSource source;
		@Required
		private String user;
		private Boolean isNewDataFetched;
		// Getters and Setters
		// ------------------
		public SocialSource getSource() {
			return this.source;
		}
		public void setSource(SocialSource source) {
			this.source = source;
		}
		public String getUser() {
			return this.user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public Boolean getIsNewDataFetched() {
			return this.isNewDataFetched;
		}
		public void setIsNewDataFetched(Boolean isNewDataFetched) {
			this.isNewDataFetched = isNewDataFetched;
		}
}
