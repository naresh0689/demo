package com.social.domain;
import org.springframework.data.mongodb.core.mapping.DBRef;

import com.social.domain.TwitterProfile;
// Imports
import com.social.domain.core.BaseDomain;
import com.social.domain.core.annotation.Required;
public class SocialProfile extends BaseDomain{
		// Field declarations
		// ------------------
	@Required
	private String userId;
	private Boolean isActive = Boolean.TRUE;
	@DBRef
	private TwitterProfile twitterProfile;
	
	public SocialProfile() {}
	
	public SocialProfile(TwitterProfile twitterProfile) {
		this.twitterProfile = twitterProfile;
	}
	
	public SocialProfile(String id) {
		this.setId(id);
	}
	
	public SocialProfile(String id, TwitterProfile twitterProfile) {
		this.setId(id);
		this.twitterProfile = twitterProfile;
	}
	
	// Getters and Setters
	// ------------------
	public String getUserId() {
		return this.userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Boolean getIsActive() {
		return this.isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public TwitterProfile getTwitterProfile() {
		return twitterProfile;
	}
	public void setTwitterProfile(TwitterProfile twitterProfile) {
		this.twitterProfile = twitterProfile;
	}
	

		
}
