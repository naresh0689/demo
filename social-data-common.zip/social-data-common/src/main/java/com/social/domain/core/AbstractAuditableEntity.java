package com.social.domain.core;

import java.util.Date;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * Base class for any domain object that requires auditable fields.
 * 
 * @author Shris Infotech
 *
 */
public abstract class AbstractAuditableEntity {
	
	@JsonIgnore
	@CreatedBy
	private String createdBy;
	
	@JsonIgnore
	@LastModifiedBy
	private String modifiedBy;
	
	@JsonIgnore
	@CreatedDate
	private Date createdDate;
	
	@JsonIgnore
	@LastModifiedDate
	private Date modifiedDate;
	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
}
