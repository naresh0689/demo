package com.social.domain;

import org.springframework.data.mongodb.core.mapping.DBRef;

import com.social.domain.core.BaseDomain;
import com.social.domain.core.UserCategory;

public class User extends BaseDomain {

	// Something that uniquely identifies each user in the system. This can be
	// emailId.
	
	private String username;
	private String firstName;
	private String lastName;
	private String password;
	@DBRef
	private SocialProfile socialProfile;
	private UserCategory category;

	public User() {
	}

	public User(String username, String password) {
		this.username = username;
		this.password = password;
	}

	public User(String username, String password, UserCategory category) {
		this.username = username;
		this.password = password;
		this.category = category;
	}

	public User(String id, String username, String password, String firstName, String lastName, UserCategory category) {
		this.setId(id);
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.category = category;
	}
	
	public User(String username, String password, String firstName, String lastName, SocialProfile socialProfile, UserCategory category) {
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.socialProfile = socialProfile;
		this.category = category;
	}
	
	public User(String id, String username, String password, String firstName, String lastName, SocialProfile socialProfile, UserCategory category) {
		this.setId(id);
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.socialProfile = socialProfile;
		this.category = category;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserCategory getCategory() {
		return category;
	}

	public void setCategory(UserCategory category) {
		this.category = category;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public SocialProfile getSocialProfile() {
		return socialProfile;
	}

	public void setSocialProfile(SocialProfile socialProfile) {
		this.socialProfile = socialProfile;
	}

}
