package com.social.domain.core;

public enum UserCategory {
	Admin, User
}
