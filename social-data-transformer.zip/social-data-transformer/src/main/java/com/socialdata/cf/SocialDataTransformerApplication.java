package com.socialdata.cf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.socialdata.cf.listener.KafkaMessageListener;

@SpringBootApplication
public class SocialDataTransformerApplication {

    public static void main(String[] args) throws Exception {
       SpringApplication.run(SocialDataTransformerApplication.class, args);
    }
    
    @Bean
    public KafkaMessageListener messageListener() {
        return new KafkaMessageListener();
    }
}
