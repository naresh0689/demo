package com.socialdata.cf.service;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.common.JSONUtil;
import com.social.domain.SocialData;
import com.socialdata.cf.domain.SocialMessage;
import com.socialdata.cf.domain.SocialMessageContent;
import com.threads.commons.PredefinedGoal;


@Service
public class TwitterCFService {
	
	@Autowired
	private PredefinedGoalsCacheService goalsCache;
	
	public SocialMessage cleanseAndFilterData(final SocialData socialData) {
		SocialMessage socialMessage = null;
		try {
			JSONObject jsonTweet = JSONUtil.getEntityFromJson(JSONObject.class, socialData.getRawMessage());
			socialMessage = new SocialMessage();
			socialMessage.setMessage_id(socialData.getId());
			socialMessage.setUser_id(socialData.getUser());
			socialMessage.setSource(socialData.getSource());
			socialMessage.setGoals(goalsCache.getPredefinedGoalsCache());
			SocialMessageContent content = new SocialMessageContent();
			content.setMessage((String) jsonTweet.get("text"));
			//content.setExtraData(tweet.getExtraData());
			socialMessage.setContent(content);
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return socialMessage;
	}
}
