package com.socialdata.cf.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.socialdata.cf.repository.PredefinedGoalRepository;
import com.threads.commons.PredefinedGoal;

//TODO move to redis cache
@Service
public class PredefinedGoalsCacheService {

	@Autowired
	private PredefinedGoalRepository predefinedGoalRepository;

	private Map<String, String> predefinedGoalsCache = new HashMap<>();

	private List<PredefinedGoal> predefinedGoalsList;

	@PostConstruct
	public void init() {
		predefinedGoalsList = predefinedGoalRepository.findAll();
		for (PredefinedGoal goal : predefinedGoalsList) {
			predefinedGoalsCache.put(goal.getId(), goal.getGoalName());
		}
	}

	public Map<String, String> getPredefinedGoalsCache() {
		return predefinedGoalsCache;
	}

	public List<PredefinedGoal> getPredefinedGoalsList() {
		return predefinedGoalsList;
	}

}
