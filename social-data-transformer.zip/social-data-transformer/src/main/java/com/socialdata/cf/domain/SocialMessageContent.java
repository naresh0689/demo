package com.socialdata.cf.domain;

import java.util.Map;

/**
 * Content of the social message.
 * 
 * @author Shris Infotech
 *
 */
public class SocialMessageContent {
	
	// Actual message posted by the user.
	private String message;

	// Any other data
//	private Map<String, Object> extraData;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

//	public Map<String, Object> getExtraData() {
//		return extraData;
//	}

//	public void setExtraData(Map<String, Object> extraData) {
//		this.extraData = extraData;
//	}
}
