package com.socialdata.cf.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.common.JSONUtil;
import com.social.domain.SocialData;
import com.social.domain.SocialSource;
import com.socialdata.cf.domain.SocialMessage;

/**
 * Does cleansing and filtering of social data and produces a normalized message
 * format that is agnostic to any social data.
 * 
 * @author Jagannadh
 *
 */
@Service
public class SocialDataCFService {
	
	@Autowired
	TwitterCFService twitterCFService;
	
	public SocialMessage cleanseAndFilterData(String message) {
		SocialMessage socialMessage = null;
		try {
			SocialData socialData = JSONUtil.getEntityFromJson(SocialData.class, message);
			if(SocialSource.Twitter.equals(socialData.getSource())) {
				socialMessage = twitterCFService.cleanseAndFilterData(socialData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return socialMessage;
	}
}
