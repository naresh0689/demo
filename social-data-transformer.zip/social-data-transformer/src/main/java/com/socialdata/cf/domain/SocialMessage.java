package com.socialdata.cf.domain;

import com.social.domain.Goal;
import com.social.domain.SocialSource;
import com.social.domain.core.annotation.Required;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents normalized social message.
 * 
 * @author Shris Infotech
 *
 */
public class SocialMessage {

	public SocialMessage() {	
	}

	
	// Id of the social message
	@Required
	private String message_id;
	
	// User for which the social message has been fetched and getting cleansed.
	@Required
	private String user_id;

	// Source of the message.
	@Required
	private SocialSource source;

	// Actual message posted by the user.
	private SocialMessageContent content;

	private Map<String,String> goals;

	public String getMessage_id() {
		return message_id;
	}

	public void setMessage_id(String message_id) {
		this.message_id = message_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public SocialSource getSource() {
		return source;
	}

	public void setSource(SocialSource source) {
		this.source = source;
	}

	public SocialMessageContent getContent() {
		return content;
	}

	public void setContent(SocialMessageContent content) {
		this.content = content;
	}


	public Map<String, String> getGoals() {
		return goals;
	}

	public void setGoals(Map<String, String> goals) {
		this.goals = goals;
	}
}	