package com.socialdata.cf.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.social.common.JSONUtil;
import com.socialdata.cf.domain.SocialMessage;
import com.socialdata.cf.service.KafkaService;
import com.socialdata.cf.service.SocialDataCFService;

public class KafkaMessageListener {
	
	@Autowired
	SocialDataCFService socialDataCFService;
	
	@Autowired
	KafkaService kafkaService;
	
    @KafkaListener(topics = "${kafka.socialdata.listen.topic.name}", group = "goals", containerFactory = "goalsKafkaListenerContainerFactory")
    public void listenToSocialMessage(String message) throws JsonProcessingException {
        System.out.println("Received social message for filtering.: " + message);
        SocialMessage socialMessage = socialDataCFService.cleanseAndFilterData(message);
        String cleansedMessage = JSONUtil.getJsonFromEntity(socialMessage);
        kafkaService.publish(cleansedMessage);
        System.out.println("Cleaned social message: " + socialMessage);
    }
}
